import { renderToString } from "@vue/server-renderer";
import { ref, inject, computed, onMounted, resolveComponent, unref, useSSRContext, onBeforeUnmount, mergeProps, withCtx, createVNode, createTextVNode, createBlock, openBlock, toDisplayString, watch, createSSRApp } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderAttrs, ssrRenderStyle, ssrRenderClass, ssrRenderList, ssrRenderSlot, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { useRoute, useRouter, createRouter, createMemoryHistory } from "vue-router";
import axios from "axios";
import { defineStore, createPinia, setActivePinia } from "pinia";
import fs from "fs";
import { fileURLToPath } from "url";
import { dirname, resolve } from "path";
const _imports_1$4 = "data:image/svg+xml,%3csvg%20width='20'%20height='17'%20viewBox='0%200%2020%2017'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M14.6751%206.70706L11.7841%202.37057L10.7896%202.88075L13.3394%206.70706H6.9792L9.50595%202.88075L8.51144%202.37057L5.62042%206.70706H1.91992L3.90316%2014.8699H16.4039L18.3871%206.70706H14.6751ZM15.4672%2013.8495H4.83985L3.35387%207.72741H4.94971L4.44667%208.49267L5.44118%209.00285L6.29114%207.72741H14.0159L14.8601%209.00285L15.8546%208.49267L15.3574%207.72741H16.959L15.4672%2013.8495Z'%20fill='%23FF7F00'/%3e%3cpath%20d='M9.5752%209.25793H10.7316V12.319H9.5752V9.25793Z'%20fill='%23FF7F00'/%3e%3cpath%20d='M6.68408%209.25793H7.84049V12.319H6.68408V9.25793Z'%20fill='%23FF7F00'/%3e%3cpath%20d='M12.4663%209.25793H13.6227V12.319H12.4663V9.25793Z'%20fill='%23FF7F00'/%3e%3c/svg%3e";
const API_BASE_URL = "http://localhost:3000/api";
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json"
  }
});
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("adminToken");
  console.log(token);
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});
const validateToken = async () => {
  try {
    await api.get("/admin/dashboard");
    return true;
  } catch (error) {
    return false;
  }
};
const fetchProducts = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/products`);
    return response.data;
  } catch (error) {
    console.error("Ошибка при получении продуктов:", error);
    throw error;
  }
};
const fetchCategories = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/categories`);
    return response.data;
  } catch (error) {
    console.log("Ошибка получения категорий", error);
  }
};
const fetchProductById = async (id) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/products/${id}`);
    return response.data;
  } catch (error) {
    console.error("Ошибка при получении продукта:", error);
    throw error;
  }
};
const fetchCategoryById = async (id) => {
  try {
    const response = await api.get(`/categories/${id}`);
    return response.data;
  } catch (error) {
    console.error("Ошибка при получении категории:", error);
    throw error;
  }
};
const fetchChildCategories = async (parentId) => {
  try {
    const response = await api.get(`/categories/children/${parentId}`);
    return response.data;
  } catch (error) {
    console.error("Ошибка при получении подкатегорий:", error);
    throw error;
  }
};
const useCartStore = defineStore("cart", {
  state: () => ({
    items: []
  }),
  actions: {
    init() {
      if (typeof window !== "undefined") {
        const saved = localStorage.getItem("cart");
        this.items = saved ? JSON.parse(saved) : [];
      }
    },
    addToCart(product) {
      const existingItem = this.items.find((item) => item.id === product.id);
      if (existingItem) {
        existingItem.quantity += 1;
      } else {
        this.items.push({ ...product, quantity: 1 });
      }
      this.saveToLocalStorage();
    },
    removeFromCart(productId) {
      this.items = this.items.filter((item) => item.id !== productId);
      this.saveToLocalStorage();
    },
    updateQuantity(productId, quantity) {
      const item = this.items.find((item2) => item2.id === productId);
      if (item) {
        item.quantity = quantity;
        this.saveToLocalStorage();
      }
    },
    clearCart() {
      this.items = [];
      this.saveToLocalStorage();
    },
    saveToLocalStorage() {
      localStorage.setItem("cart", JSON.stringify(this.items));
    }
  },
  getters: {
    totalItems: (state) => state.items.reduce((total, item) => total + item.quantity, 0),
    totalPrice: (state) => state.items.reduce((total, item) => total + item.price * item.quantity, 0)
  }
});
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const _sfc_main$s = {
  __name: "App",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    useRouter();
    const products = ref(inject("initialProducts", []));
    const categories = ref(inject("initialCategories", []));
    const parentCategories = ref([]);
    const loading = ref(true);
    const cartStore = useCartStore();
    const isAdminRoute = computed(() => {
      return route.path.startsWith("/admin") || route.path.startsWith("/basket");
    });
    onMounted(async () => {
      if (products.value.length === 0 || categories.value.length === 0) {
        loading.value = true;
        try {
          const [productsData, categoriesData] = await Promise.all([
            fetchProducts(),
            fetchCategories()
          ]);
          products.value = productsData;
          categories.value = categoriesData;
        } catch (err) {
          console.error("Ошибка загрузки данных:", err);
        } finally {
          loading.value = false;
        }
      }
      parentCategories.value = categories.value.filter((c) => c.parent_id === null);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_view = resolveComponent("router-view");
      _push(`<!--[--><div data-v-108a5f17>`);
      _push(ssrRenderComponent(_component_router_view, {
        class: "wrapper",
        products: products.value,
        categories: categories.value,
        parentCategories: parentCategories.value,
        loading: loading.value
      }, null, _parent));
      _push(`</div>`);
      if (!isAdminRoute.value) {
        _push(`<div class="basket" data-v-108a5f17><img${ssrRenderAttr("src", _imports_1$4)} alt="" data-v-108a5f17>`);
        if (unref(cartStore).totalItems > 0) {
          _push(`<span class="cart-badge" data-v-108a5f17>${ssrInterpolate(unref(cartStore).totalItems)}</span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$s = _sfc_main$s.setup;
_sfc_main$s.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/App.vue");
  return _sfc_setup$s ? _sfc_setup$s(props, ctx) : void 0;
};
const App = /* @__PURE__ */ _export_sfc(_sfc_main$s, [["__scopeId", "data-v-108a5f17"]]);
const _imports_0$3 = "/assets/logo-CGeZRa6m.png";
const _imports_1$3 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAJCAYAAADtj3ZXAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAACzSURBVHgBlZFhDcIwEIXfVUElIGEOAAVkEnAwBWNgAByAAzIFCwqGBCRUAeVd2RoyWsKatD9ev+96ucLv0PkGK8xYytPrDQQ3eFwZFH+KhfJ4opUQ1DixyIZ7LQ0eP8QFxY67lQMqiRc1LpSXuQJRBO6yR6mZibcGFU+nAEGbER2Lb8dcJpAl1A+QduCGTEU77cp8ygorEECP47sizinx6+VEmyOVnINJyQGUMBTtpMz9wAsO80iWHmMtiQAAAABJRU5ErkJggg==";
const _imports_1$2 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAEASURBVHgBlVLRtQExEL2T9/6fEpTwSlgVoAJUgAIQjn90QAWoACXoQAe2AeImYs3Z4xB3TzaTu3tvJpkBItwIMzdGC1/ABOEAFsLniuU3BuIsMjjsGO85H2nRxQVNmWLzSWxUnFH4R4MV2QwJ+OU4qXU7DINtitiIDeK8YH6Qk8uTxOEtWBTMlZeXiMeZ53im/+/LliwOaQo6iu+5IUZJ4miwp8G4+CKw2oAlrfh+8PPzlxIoWJLVjTKPpg2W0Zv5LGs+W1MWy4Sl8rVWR+D6zDGLJtUQv9pZpWnjTho5u6/Dcq7D7ngDGrSjQVXRJwr7THvzVlwyqTOsUHgQe++FG6QdUW+L3yMtAAAAAElFTkSuQmCC";
const _sfc_main$r = {
  __name: "NavBar",
  __ssrInlineRender: true,
  props: {
    parentCategories: {
      type: Array,
      required: true,
      default: () => []
    }
  },
  setup(__props) {
    useRouter();
    const isMenuOpen = ref(false);
    const isDropdownOpen = ref(false);
    const isMobile = ref(false);
    const updateIsMobile = () => {
      if (typeof window !== "undefined") {
        isMobile.value = window.innerWidth <= 768;
        if (!isMobile.value) {
          isDropdownOpen.value = false;
        }
      }
    };
    onMounted(() => {
      updateIsMobile();
      window.addEventListener("resize", updateIsMobile);
      document.addEventListener("click", closeDropdownOnClickOutside);
    });
    onBeforeUnmount(() => {
      window.removeEventListener("resize", updateIsMobile);
      document.removeEventListener("click", closeDropdownOnClickOutside);
    });
    const handleDropdownClick = (event) => {
      if (isMobile.value) {
        event.preventDefault();
        isDropdownOpen.value = !isDropdownOpen.value;
      }
    };
    const closeDropdownOnClickOutside = (event) => {
      if (typeof document !== "undefined") {
        const dropdown = document.querySelector(".dropdown");
        if (dropdown && !dropdown.contains(event.target)) {
          isDropdownOpen.value = false;
        }
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "nav" }, _attrs))} data-v-40b7182c><div class="nav-wrapp container" data-v-40b7182c><div class="logo-wrapp" data-v-40b7182c>`);
      _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0$3)} alt="Voe logo" class="logo-img" style="${ssrRenderStyle({ "width": "135px", "height": "74px" })}" data-v-40b7182c${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0$3,
                alt: "Voe logo",
                class: "logo-img",
                style: { "width": "135px", "height": "74px" }
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="${ssrRenderClass([{ "active": isMenuOpen.value }, "burger"])}" data-v-40b7182c><span data-v-40b7182c></span><span data-v-40b7182c></span><span data-v-40b7182c></span></div><div class="${ssrRenderClass([{ "active": isMenuOpen.value }, "nav-content"])}" data-v-40b7182c><div class="nav-links" data-v-40b7182c><div class="link" data-v-40b7182c>`);
      _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Главная`);
          } else {
            return [
              createTextVNode("Главная")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="link" data-v-40b7182c><div class="dropdown" data-v-40b7182c>`);
      _push(ssrRenderComponent(_component_router_link, {
        to: "/catalog",
        onClick: handleDropdownClick
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Каталог продукции <img${ssrRenderAttr("src", _imports_1$3)} alt="" class="${ssrRenderClass([{ "rotated": isDropdownOpen.value }, "arrow-img"])}" data-v-40b7182c${_scopeId}>`);
          } else {
            return [
              createTextVNode(" Каталог продукции "),
              createVNode("img", {
                src: _imports_1$3,
                alt: "",
                class: ["arrow-img", { "rotated": isDropdownOpen.value }]
              }, null, 2)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<ul class="${ssrRenderClass([{ "open": isDropdownOpen.value }, "dropdown-menu"])}" data-v-40b7182c><!--[-->`);
      ssrRenderList(__props.parentCategories, (category) => {
        _push(`<li data-v-40b7182c>${ssrInterpolate(category.name)}</li>`);
      });
      _push(`<!--]--></ul></div></div><div class="link" data-v-40b7182c>`);
      _push(ssrRenderComponent(_component_router_link, { to: "/about-us" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`О компании`);
          } else {
            return [
              createTextVNode("О компании")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="link" data-v-40b7182c>`);
      _push(ssrRenderComponent(_component_router_link, { to: "/contacts" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Контакты`);
          } else {
            return [
              createTextVNode("Контакты")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="nav-contacts" data-v-40b7182c><img${ssrRenderAttr("src", _imports_1$2)} alt="" data-v-40b7182c><div class="contacts-number" data-v-40b7182c><span data-v-40b7182c>Свяжитесь с нами</span><span data-v-40b7182c>+7(1234)-56-78-90</span><span data-v-40b7182c>+7(1234)-56-78-90</span></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$r = _sfc_main$r.setup;
_sfc_main$r.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/NavBar.vue");
  return _sfc_setup$r ? _sfc_setup$r(props, ctx) : void 0;
};
const NavBar = /* @__PURE__ */ _export_sfc(_sfc_main$r, [["__scopeId", "data-v-40b7182c"]]);
const _sfc_main$q = {
  __name: "ButtonComp",
  __ssrInlineRender: true,
  props: {
    variant: {
      type: String,
      default: "primary",
      // значение по умолчанию
      validator: (value) => ["primary", "transparent"].includes(value)
      // валидация вариантов
    }
  },
  setup(__props) {
    const props = __props;
    const dynamicClass = computed(() => {
      return {
        primary: "",
        transparent: "btn-transparent"
      }[props.variant];
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<button${ssrRenderAttrs(mergeProps({
        class: ["btn", dynamicClass.value]
      }, _attrs))} data-v-a1dc0c17>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</button>`);
    };
  }
};
const _sfc_setup$q = _sfc_main$q.setup;
_sfc_main$q.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/UI/ButtonComp.vue");
  return _sfc_setup$q ? _sfc_setup$q(props, ctx) : void 0;
};
const ButtonComp = /* @__PURE__ */ _export_sfc(_sfc_main$q, [["__scopeId", "data-v-a1dc0c17"]]);
const _sfc_main$p = {
  __name: "CarouselComp",
  __ssrInlineRender: true,
  props: {
    products: {
      type: Array,
      required: true
    },
    categories: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    const router = useRouter();
    const props = __props;
    onMounted(() => {
      if (parentCategories.value.length > 0) {
        const preloadImage = `http://localhost:3000${parentCategories.value[0].image_url}`;
        const link = document.createElement("link");
        link.rel = "preload";
        link.as = "image";
        link.href = preloadImage;
        document.head.appendChild(link);
      }
    });
    const getImage = (imageUrl) => {
      return `http://localhost:3000${imageUrl}`;
    };
    const slides = computed(() => {
      return parentCategories.value.map((category) => ({
        title: category.name,
        description: category.description || "Описание категории отсутствует",
        // Описание, если доступно
        image: getImage(category.image_url),
        // Предполагается, что у категории есть image_url
        categoryId: category.id
      }));
    });
    const parentCategories = computed(() => {
      return props.categories.filter((category) => !category.parent_id);
    });
    const navigateToCategory = (categoryId) => {
      router.push({
        name: "catalog",
        query: { category: categoryId }
      });
    };
    const currentIndex = ref(0);
    ref(0);
    ref(0);
    const trackStyle = computed(() => ({
      transform: `translateX(-${currentIndex.value * 100}%)`,
      transition: "transform 0.5s ease"
    }));
    const nextSlide = () => {
      currentIndex.value = (currentIndex.value + 1) % slides.value.length;
    };
    let interval;
    const startInterval = () => {
      interval = setInterval(() => {
        nextSlide();
      }, 5e3);
    };
    const stopInterval = () => {
      clearInterval(interval);
    };
    onMounted(() => {
      startInterval();
    });
    onBeforeUnmount(() => {
      stopInterval();
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "slider" }, _attrs))} data-v-a2d1de8c><div style="${ssrRenderStyle(slides.value.length > 0 ? null : { display: "none" })}" class="slider-container" data-v-a2d1de8c><div class="slider-track" style="${ssrRenderStyle(trackStyle.value)}" data-v-a2d1de8c><!--[-->`);
      ssrRenderList(slides.value, (slide, index) => {
        _push(`<div class="slide" data-v-a2d1de8c><div class="slide-content" data-v-a2d1de8c><div class="text-content" data-v-a2d1de8c><h2 class="slide-title" data-v-a2d1de8c>${ssrInterpolate(slide.title)}</h2><p class="slide-description" data-v-a2d1de8c>${ssrInterpolate(slide.description)}</p>`);
        _push(ssrRenderComponent(ButtonComp, {
          onClick: ($event) => navigateToCategory(slide.categoryId)
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Узнать больше`);
            } else {
              return [
                createTextVNode("Узнать больше")
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div><div class="image-content" data-v-a2d1de8c><img${ssrRenderAttr("src", slide.image)}${ssrRenderAttr("alt", slide.title)} width="350" height="300" decoding="async" loading="eager" fetchpriority="high" data-v-a2d1de8c></div></div></div>`);
      });
      _push(`<!--]--></div><div class="indicators" data-v-a2d1de8c><!--[-->`);
      ssrRenderList(slides.value, (slide, index) => {
        _push(`<button class="${ssrRenderClass(["indicator", { active: currentIndex.value === index }])}"${ssrRenderAttr("aria-label", "Go to slide " + (index + 1))} data-v-a2d1de8c></button>`);
      });
      _push(`<!--]--></div></div><div style="${ssrRenderStyle(slides.value.length === 0 ? null : { display: "none" })}" class="error-message" data-v-a2d1de8c><p data-v-a2d1de8c>К сожалению, на данный момент товары отсутствуют. Попробуйте позже!</p></div></div>`);
    };
  }
};
const _sfc_setup$p = _sfc_main$p.setup;
_sfc_main$p.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/MainPage/components/CarouselComp.vue");
  return _sfc_setup$p ? _sfc_setup$p(props, ctx) : void 0;
};
const CarouselComp = /* @__PURE__ */ _export_sfc(_sfc_main$p, [["__scopeId", "data-v-a2d1de8c"]]);
const _sfc_main$o = {
  __name: "CarouselAbout",
  __ssrInlineRender: true,
  props: {
    products: {
      type: Array,
      required: true,
      default: () => []
    },
    categories: {
      type: Array,
      required: true,
      default: () => []
    }
  },
  setup(__props) {
    const router = useRouter();
    const props = __props;
    const position = ref(0);
    ref(0);
    ref(false);
    const currentIndex = ref(0);
    const hoverIndex = ref(null);
    const slider = ref(null);
    ref(0);
    ref(0);
    const getImage = (imageUrl) => {
      return `http://localhost:3000${imageUrl}`;
    };
    const cardWidth = computed(() => {
      return slider.value ? slider.value.offsetWidth / visibleCards.value : 0;
    });
    computed(() => {
      return -((cards.value.length - visibleCards.value) * cardWidth.value);
    });
    const visibleCards = computed(() => {
      if (window.innerWidth >= 1200) return 4;
      if (window.innerWidth >= 768) return 3;
      if (window.innerWidth >= 480) return 2;
      return 1;
    });
    const cards = computed(() => {
      const subcategoryIds = props.categories.filter((category) => category.parent_id !== null).map((category) => category.id);
      return props.products.filter((product) => subcategoryIds.includes(product.category_id)).map((product) => ({
        id: product.id,
        title: product.name,
        name: product.name,
        description: product.description,
        image: getImage(product.image_url)
      }));
    });
    const navigateToProduct = (productId) => {
      router.push({
        name: "product",
        params: { id: productId }
      });
    };
    const slideTo = (index) => {
      index = Math.max(0, Math.min(index, cards.value.length - visibleCards.value));
      currentIndex.value = index;
      position.value = -index * cardWidth.value;
    };
    const handleResize = () => {
      slideTo(currentIndex.value);
    };
    onMounted(() => {
      window.addEventListener("resize", handleResize);
    });
    onBeforeUnmount(() => {
      window.removeEventListener("resize", handleResize);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "slider-container" }, _attrs))} data-v-5f00ca90>`);
      if (props.products && props.products.length > 0) {
        _push(`<div class="slider" data-v-5f00ca90><div class="slide-track" style="${ssrRenderStyle({ transform: `translateX(${position.value}px)` })}" data-v-5f00ca90><!--[-->`);
        ssrRenderList(cards.value, (card, index) => {
          _push(`<div class="card" data-v-5f00ca90><div class="card-cont" data-v-5f00ca90><div class="card-image" data-v-5f00ca90><img${ssrRenderAttr("src", card.image)}${ssrRenderAttr("alt", card.title)} data-v-5f00ca90></div><div class="card-text" data-v-5f00ca90>${ssrInterpolate(card.name)}</div><div class="${ssrRenderClass([{ "active": hoverIndex.value === index }, "card-overlay"])}" data-v-5f00ca90><div class="overlay-content" data-v-5f00ca90><div class="overlay-text" data-v-5f00ca90>${ssrInterpolate(card.description)}</div><div class="overlay-button" data-v-5f00ca90>`);
          _push(ssrRenderComponent(ButtonComp, {
            variant: "transparent",
            onClick: ($event) => navigateToProduct(card.id)
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`Подробнее`);
              } else {
                return [
                  createTextVNode("Подробнее")
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div></div></div></div></div>`);
        });
        _push(`<!--]--></div></div>`);
      } else {
        _push(`<div data-v-5f00ca90><p class="error-message" data-v-5f00ca90>К сожалению, на данный момент товары отсутствуют. Попробуйте позже!</p></div>`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$o = _sfc_main$o.setup;
_sfc_main$o.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/MainPage/components/CarouselAbout.vue");
  return _sfc_setup$o ? _sfc_setup$o(props, ctx) : void 0;
};
const CarouselAbout = /* @__PURE__ */ _export_sfc(_sfc_main$o, [["__scopeId", "data-v-5f00ca90"]]);
const _imports_0$2 = "/assets/card-1-CZkTgrWw.png";
const _imports_1$1 = "/assets/card-3-DeiLfOEC.png";
const _sfc_main$n = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "card-container" }, _attrs))} data-v-1b3d7aac><div class="card" data-v-1b3d7aac><img${ssrRenderAttr("src", _imports_0$2)} alt="" data-v-1b3d7aac><div class="card-title" data-v-1b3d7aac>До 2 лет</div><div class="card-description" data-v-1b3d7aac>Гарантии на выпускаемую продукцию</div><div class="corner-arrow top-left" data-v-1b3d7aac></div><div class="corner-arrow bottom-right" data-v-1b3d7aac></div></div><div class="card" data-v-1b3d7aac><img${ssrRenderAttr("src", _imports_1$1)} alt="" data-v-1b3d7aac><div class="card-title" data-v-1b3d7aac>435834</div><div class="card-description" data-v-1b3d7aac>Выпущенной продукции</div><div class="corner-arrow top-left" data-v-1b3d7aac></div><div class="corner-arrow bottom-right" data-v-1b3d7aac></div></div><div class="card" data-v-1b3d7aac><img${ssrRenderAttr("src", _imports_1$1)} alt="" data-v-1b3d7aac><div class="card-title" data-v-1b3d7aac>47</div><div class="card-description" data-v-1b3d7aac>Квалифицированных сотрудников</div><div class="corner-arrow top-left" data-v-1b3d7aac></div><div class="corner-arrow bottom-right" data-v-1b3d7aac></div></div><div class="card" data-v-1b3d7aac><img${ssrRenderAttr("src", _imports_0$2)} alt="" data-v-1b3d7aac><div class="card-title" data-v-1b3d7aac>562 кв.м.</div><div class="card-description" data-v-1b3d7aac>Производственных площадей</div><div class="corner-arrow top-left" data-v-1b3d7aac></div><div class="corner-arrow bottom-right" data-v-1b3d7aac></div></div></div>`);
}
const _sfc_setup$n = _sfc_main$n.setup;
_sfc_main$n.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/MainPage/components/WhyWeCards.vue");
  return _sfc_setup$n ? _sfc_setup$n(props, ctx) : void 0;
};
const WhyWeCards = /* @__PURE__ */ _export_sfc(_sfc_main$n, [["ssrRender", _sfc_ssrRender$1], ["__scopeId", "data-v-1b3d7aac"]]);
const _sfc_main$m = {
  __name: "ConsultationRequest",
  __ssrInlineRender: true,
  props: {
    isFromCart: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    const form = ref({
      name: "",
      phone: "",
      email: "",
      message: ""
    });
    const isLoading = ref(false);
    const showToast = ref(false);
    const toastMessage = ref("");
    const toastSuccess = ref(false);
    useCartStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "consultation" }, _attrs))} data-v-13b6c096>`);
      if (showToast.value) {
        _push(`<div class="${ssrRenderClass([{ success: toastSuccess.value }, "toast"])}" data-v-13b6c096>${ssrInterpolate(toastMessage.value)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="consultation-cont container" data-v-13b6c096><div class="consultation-title" data-v-13b6c096><h3 data-v-13b6c096>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</h3></div><div class="consultation-form" data-v-13b6c096><div class="form-wrapper" data-v-13b6c096><div class="form-cont" data-v-13b6c096><form data-v-13b6c096><div class="inputs-group" data-v-13b6c096><div class="input-group" data-v-13b6c096><input required type="text" placeholder="Ваше имя"${ssrRenderAttr("value", form.value.name)}${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""} data-v-13b6c096></div><div class="input-group" data-v-13b6c096><input required type="tel" placeholder="Телефон"${ssrRenderAttr("value", form.value.phone)}${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""} data-v-13b6c096></div><div class="input-group" data-v-13b6c096><input required type="email" placeholder="Email"${ssrRenderAttr("value", form.value.email)} pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,}$"${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""} data-v-13b6c096></div></div><div class="textarea-group" data-v-13b6c096><textarea required placeholder="Комментарий"${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""} data-v-13b6c096>${ssrInterpolate(form.value.message)}</textarea></div>`);
      _push(ssrRenderComponent(ButtonComp, {
        class: "submit-btn",
        disabled: isLoading.value
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (!isLoading.value) {
              _push2(`<span data-v-13b6c096${_scopeId}>Отправить</span>`);
            } else {
              _push2(`<span class="loader" data-v-13b6c096${_scopeId}></span>`);
            }
          } else {
            return [
              !isLoading.value ? (openBlock(), createBlock("span", { key: 0 }, "Отправить")) : (openBlock(), createBlock("span", {
                key: 1,
                class: "loader"
              }))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</form></div><span class="consent-text" data-v-13b6c096>Оставляя заявку вы соглашаетесь с политикой обработки `);
      _push(ssrRenderComponent(_component_router_link, { to: "/privacy-policy" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`персональных данных`);
          } else {
            return [
              createTextVNode("персональных данных")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</span></div></div></div></div>`);
    };
  }
};
const _sfc_setup$m = _sfc_main$m.setup;
_sfc_main$m.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/ConsultationRequest.vue");
  return _sfc_setup$m ? _sfc_setup$m(props, ctx) : void 0;
};
const ConsultationRequest = /* @__PURE__ */ _export_sfc(_sfc_main$m, [["__scopeId", "data-v-13b6c096"]]);
const _imports_2$1 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAANCAYAAAB2HjRBAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAADqSURBVHgBnVLtEcFAEH13UoAS6IAKjApQAR3gv5HLKAAViAroQDqIDighDSTn7YnBTL54Mzub3Ozb93bvlDXwYbEA0MYvyLD0HJEfaOHemGjRg4bvOUWNAXOkTH0DOhWHI+EpK6aBxEWGvdpgV0rKMIdyIwra2iWFPiOggzmb3ewa0y/iCmNKxDkxcPWEfhXQcsjDIePICNkkFhLzhfs45OddFbydeZ8K+czGSqMMhqQT/8+iVLQPr2i+vHBG1SmVJiiBRhVkjApUkukg+ptcB5k5QcqtGlwbs1J0KJsIWe53655KU+jng3oAnB9IgT4E3CMAAAAASUVORK5CYII=";
const _imports_3$1 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAARCAYAAADtyJ2fAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAEiSURBVHgBlVILUcQwEH3JIKASKuFQACiAU0BRwFQA01QBnALulFAJoIBKqAEIb5Ntkwm0wJvpZz9v/wYZvMMlPnEDg2uKtapfw2NwMg7D7GuUUMHjkb8NtnEko2WA6SymwgvfOzVONB40E7SCC62goa98r4x/oGDxrKSRTucSsWih1uC1BustSfdIhe9LUlC7EPBuUVjcGt8x1uzQx57XkPvaUF4qqVoluWUGoSUrY07WpdeSVBW2wajyncKcbaTsWMsbZMIf3G2cw26xG05VIzo6d/gLLBrT4WRVfELW6waOQop8hHHL0ve/kKTENiVWkCyX0q6QptBXtmObW7lHKXn4gdiHI8hgv7nEC0nX43HQgNgkFuc10sPhP5AVheNewRd0HFx8F9ePSgAAAABJRU5ErkJggg==";
const _imports_4 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAEuSURBVHgBlVONWcJADH0XF8ANGMEN1A1wAuoEMoB6pwuoG7QT+DmBOoF1AhiBBeB4Sa+0hYMP8n1pe2le8vJzDjsSn1BAMOXnFXVEXVJrRJTuFVXf121BAWM6fBpA8M7v3wQcWaAInxC3LmCBPjB6zOMzQX0Wj5gMzgHB/DQRRRorvrFGRVqzQQ0XxqSjSTB9vxLDpkaNhozQHg/YleVUrDnCiOfJB2svlLY24/8sqMOP4hTcjiMr8cXGtis2BUE3jlyGezayzASwhAquscJNFhtQbgOEXoKVLVAt/FmxYQ84ICnAJd9dacKFEdqtLo8/6htOEDLw7Wgl1XbH54Sz80eBmiBy97miDayLOLZNswPnLja+pplrXNNzZmcmanfbZWgVBO/fKtbo/PBWbQDY8XBNGddBuwAAAABJRU5ErkJggg==";
const _sfc_main$l = {
  __name: "FooterComp",
  __ssrInlineRender: true,
  props: {
    parentCategories: {
      type: Array,
      default: () => []
    }
  },
  setup(__props) {
    const router = useRouter();
    const selectCategory = (categoryId) => {
      router.push({
        name: "catalog",
        query: { parent: categoryId }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "footer" }, _attrs))} data-v-e7a50888><div class="footer-cont container" data-v-e7a50888><div class="footer-wrapper" data-v-e7a50888><div class="footer-logo" data-v-e7a50888><img${ssrRenderAttr("src", _imports_0$3)} alt="Логотип" style="${ssrRenderStyle({ "width": "197px", "height": "150px" })}" data-v-e7a50888></div><div class="footer-links footer-card" data-v-e7a50888><h4 data-v-e7a50888>Каталог</h4><div class="footer-links" data-v-e7a50888><!--[-->`);
      ssrRenderList(__props.parentCategories, (category) => {
        _push(ssrRenderComponent(_component_router_link, {
          key: category.id,
          to: { name: "catalog", query: { category: category.id } },
          onClick: ($event) => selectCategory(category.id)
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(category.name)}`);
            } else {
              return [
                createTextVNode(toDisplayString(category.name), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]--></div></div><div class="footer-links" data-v-e7a50888><h4 data-v-e7a50888>Меню</h4><div class="footer-links" data-v-e7a50888>`);
      _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Главная`);
          } else {
            return [
              createTextVNode("Главная")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_router_link, { to: "/catalog" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Каталог продукции`);
          } else {
            return [
              createTextVNode("Каталог продукции")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_router_link, { to: "/about-us" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`О компании`);
          } else {
            return [
              createTextVNode("О компании")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_router_link, { to: "/contacts" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Контакты`);
          } else {
            return [
              createTextVNode("Контакты")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="footer-links" data-v-e7a50888><h4 data-v-e7a50888>Контакты</h4><div class="footer-links" data-v-e7a50888><div class="link-title" data-v-e7a50888><img${ssrRenderAttr("src", _imports_1$2)} alt="Телефон" data-v-e7a50888><div class="link-description" data-v-e7a50888><span data-v-e7a50888>+7(1234)-56-78-90</span><span data-v-e7a50888>+7(1234)-56-78-90</span></div></div><div class="link-title" data-v-e7a50888><img${ssrRenderAttr("src", _imports_2$1)} alt="Email" data-v-e7a50888><span data-v-e7a50888>pochta@gmail.com</span></div><div class="link-title" data-v-e7a50888><img${ssrRenderAttr("src", _imports_3$1)} alt="Адрес" data-v-e7a50888><span data-v-e7a50888>г. Ижевск</span></div><div class="link-title" data-v-e7a50888><img${ssrRenderAttr("src", _imports_4)} alt="Часы работы" data-v-e7a50888><span data-v-e7a50888>Пн.-Пт. с 9:00-18:00</span></div></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$l = _sfc_main$l.setup;
_sfc_main$l.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/FooterComp.vue");
  return _sfc_setup$l ? _sfc_setup$l(props, ctx) : void 0;
};
const FooterComp = /* @__PURE__ */ _export_sfc(_sfc_main$l, [["__scopeId", "data-v-e7a50888"]]);
const _sfc_main$k = {};
const _sfc_setup$k = _sfc_main$k.setup;
_sfc_main$k.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/CreateProduct.vue");
  return _sfc_setup$k ? _sfc_setup$k(props, ctx) : void 0;
};
const _sfc_main$j = {};
const _sfc_setup$j = _sfc_main$j.setup;
_sfc_main$j.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/deleteCategory.vue");
  return _sfc_setup$j ? _sfc_setup$j(props, ctx) : void 0;
};
const _sfc_main$i = {};
const _sfc_setup$i = _sfc_main$i.setup;
_sfc_main$i.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/ProductList.vue");
  return _sfc_setup$i ? _sfc_setup$i(props, ctx) : void 0;
};
const _sfc_main$h = {
  __name: "MainPage",
  __ssrInlineRender: true,
  props: {
    products: {
      type: Array,
      required: true,
      default: () => []
    },
    categories: {
      type: Array,
      required: true,
      default: () => []
    },
    loading: {
      type: Boolean,
      default: false
    },
    parentCategories: {
      type: Array,
      default: () => []
    }
  },
  setup(__props) {
    const props = __props;
    const safeCategories = computed(() => {
      return Array.isArray(props.categories) ? props.categories : [];
    });
    const filteredParentCategoryProducts = computed(() => {
      const parentCategoryIds = safeCategories.value.filter((category) => (category == null ? void 0 : category.parent_id) === null).map((category) => category == null ? void 0 : category.id).filter(Boolean);
      return Array.isArray(props.products) ? props.products.filter((product) => (product == null ? void 0 : product.category_id) && parentCategoryIds.includes(product.category_id)) : [];
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      if (__props.loading) {
        _push(`<div class="loading-overlay" data-v-3b80b19e><div class="spinner" data-v-3b80b19e></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div data-v-3b80b19e>`);
      _push(ssrRenderComponent(NavBar, { parentCategories: __props.parentCategories }, null, _parent));
      _push(`<section class="carousel" data-v-3b80b19e><div class="carousel-wrapp container" style="${ssrRenderStyle({ minHeight: __props.loading ? "450px" : "auto" })}" data-v-3b80b19e>`);
      _push(ssrRenderComponent(CarouselComp, {
        products: filteredParentCategoryProducts.value,
        categories: __props.categories,
        loading: __props.loading
      }, null, _parent));
      _push(`</div></section><section class="carousel-about" data-v-3b80b19e><div class="carousel-about-wrapp container" data-v-3b80b19e><div class="carousel-about-title" data-v-3b80b19e><h2 data-v-3b80b19e>Каталог продукции</h2><span data-v-3b80b19e>Широкий ассортимент насосов и запасных деталей</span></div>`);
      _push(ssrRenderComponent(CarouselAbout, {
        products: __props.products,
        categories: __props.categories
      }, null, _parent));
      _push(`</div></section><section class="why-we" data-v-3b80b19e><div class="why-we-wrapp container" data-v-3b80b19e><h2 class="why-we-title" data-v-3b80b19e>Почему <span class="why-we-title-2" data-v-3b80b19e>мы</span></h2><div class="why-we-pluses" data-v-3b80b19e><div class="pluses-title" data-v-3b80b19e><h2 data-v-3b80b19e>ООО «Виктори Ойл Энерджи»- это современная динамично развивающаяся компания, основным видом деятельности которой является производство и продажа запасных частей, оборудования для систем очистки бурового раствора зарубежных фирм Derrick, Swaco, Brand.</h2><p data-v-3b80b19e>Высокое качество выпускаемой продукции, короткие сроки изготовления, вся продукция сертифицирована. Различные виды логистических решений для наших покупателей с учетом их требований. Большой ассортимент готовой продукции на складе. Гарантия на продукцию от 1 года до 2 лет. </p></div><div class="pluses-cards" data-v-3b80b19e>`);
      _push(ssrRenderComponent(WhyWeCards, null, null, _parent));
      _push(`</div></div></div></section>`);
      _push(ssrRenderComponent(ConsultationRequest, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Оставьте заявку на консультацию`);
          } else {
            return [
              createTextVNode("Оставьте заявку на консультацию")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(FooterComp, { parentCategories: __props.parentCategories }, null, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup$h = _sfc_main$h.setup;
_sfc_main$h.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/MainPage/MainPage.vue");
  return _sfc_setup$h ? _sfc_setup$h(props, ctx) : void 0;
};
const MainPage = /* @__PURE__ */ _export_sfc(_sfc_main$h, [["__scopeId", "data-v-3b80b19e"]]);
const _sfc_main$g = {
  __name: "AboutTitle",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "about-title" }, _attrs))} data-v-f7194637><div class="container text-content" data-v-f7194637><h1 data-v-f7194637>ООО «Виктори Ойл Энерджи»</h1><p data-v-f7194637> Это современная динамично развивающаяся компания, основным видом деятельности которой является производство и продажа запасных частей, оборудования для систем очистки бурового раствора зарубежных фирм Derrick, Swaco, Brand.<br data-v-f7194637> Так же компания освоила производство запасных частей для шламовых насосов MCM, Halco, Derrick, SB, XBSY.<br data-v-f7194637> Основными покупателями нашей продукции являются буровые и сервисные компании России и страны ближнего зарубежья: Белоруссия, Казахстан, Узбекистан.<br data-v-f7194637> Собственный парк оборудования и квалифицированные специалисты дают нам возможность контролировать весь цикл производства от закупа сырья до выпуска готового изделия. Вся продукция проходит обязательную сертификацию.<br data-v-f7194637> Наши менеджеры и сервисный отдел на каждом этапе сделки сопровождают Покупателя, ускоряя процесс изготовления до поставки оборудования на склад заказчика.<br data-v-f7194637> Кроме собственной линейки производимых запасных частей мы можем изготовить изделие под заказ по чертежу или образцу заказчика.<br data-v-f7194637></p></div></div>`);
    };
  }
};
const _sfc_setup$g = _sfc_main$g.setup;
_sfc_main$g.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/AboutUs/components/AboutTitle.vue");
  return _sfc_setup$g ? _sfc_setup$g(props, ctx) : void 0;
};
const AboutTitle = /* @__PURE__ */ _export_sfc(_sfc_main$g, [["__scopeId", "data-v-f7194637"]]);
const _sfc_main$f = {
  __name: "AboutPluses",
  __ssrInlineRender: true,
  props: {
    backgroundColor: {
      type: String,
      default: "var(--primary-dark-gray)"
    },
    textColor: {
      type: String,
      default: "var(--primary-dark-color)"
    },
    borderColor: {
      type: String,
      default: "var(--primary-orange-color)"
    },
    showTitle: {
      type: Boolean,
      default: true
    }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "about-pluses",
        style: {
          "--bg-color": props.backgroundColor,
          "--text-color": props.textColor
        }
      }, _attrs))} data-v-4c5e6a5f><div class="about-pluses-wrapp container" data-v-4c5e6a5f>`);
      if (props.showTitle) {
        _push(`<div class="pluses-title" data-v-4c5e6a5f><h2 style="${ssrRenderStyle({ "--border-color": props.borderColor })}" data-v-4c5e6a5f>Почему выбирают нас</h2><span data-v-4c5e6a5f>Многолетний опыт, качество продукции, доверие клиентов помогло стать успешной компанией</span></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="card-container" data-v-4c5e6a5f><div class="card" data-v-4c5e6a5f><img${ssrRenderAttr("src", _imports_0$2)} alt="" data-v-4c5e6a5f><div class="card-title" data-v-4c5e6a5f>До 2 лет</div><div class="card-description" data-v-4c5e6a5f>Гарантии на выпускаемую продукцию</div></div><div class="card" data-v-4c5e6a5f><img${ssrRenderAttr("src", _imports_1$1)} alt="" data-v-4c5e6a5f><div class="card-title" data-v-4c5e6a5f>435834</div><div class="card-description" data-v-4c5e6a5f>Выпущенной продукции</div></div><div class="card" data-v-4c5e6a5f><img${ssrRenderAttr("src", _imports_1$1)} alt="" data-v-4c5e6a5f><div class="card-title" data-v-4c5e6a5f>47</div><div class="card-description" data-v-4c5e6a5f>Квалифицированных сотрудников</div></div><div class="card" data-v-4c5e6a5f><img${ssrRenderAttr("src", _imports_0$2)} alt="" data-v-4c5e6a5f><div class="card-title" data-v-4c5e6a5f>562 кв.м.</div><div class="card-description" data-v-4c5e6a5f>Производственных площадей</div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$f = _sfc_main$f.setup;
_sfc_main$f.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/AboutPluses.vue");
  return _sfc_setup$f ? _sfc_setup$f(props, ctx) : void 0;
};
const AboutPluses = /* @__PURE__ */ _export_sfc(_sfc_main$f, [["__scopeId", "data-v-4c5e6a5f"]]);
const _imports_0$1 = "/assets/quality-CnWlkGkt.png";
const _imports_1 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHQAAABNCAYAAAB370BCAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAQ8SURBVHgB7Z39VdswFMWvAgMwgjcAJqiZgGxAOgEwAE1y2v8hExQmaJigYYMwAe4GXqBRn2wn2CYfirAVP/X9zjHYRuDEN3r6us8oWKDHuMICD7R7gvZJoTBWo+x6wp70rEotcAM/YiK7jsY1BCfsBPUnpvBJjrE/cwqJczSNxhl9PbMqOkIED1DYT8CM/QVVeKY3OkLDaPM39XZBMyE1ftMWwQN6SIIqnNP7TcEE25DbFWLaIvgjoq0PRnATVNiBSxvaHWh4gzbQGFoVG2VNhJcOI4X9mU051oK20ZYbqO0cWpS5J+Fv4Am63oMa43ZXOQm57vhuW62uJ4IGBu82tCsoTPEXz2iaI1xSWN8rEoigzfCqvuMRDVNMoOwlqITcwBBBA0MEDQwRNDBU+YAa4Zh6VZf4OPvRL52bF1vTlFdbzGT4dE2ZCPl87pJHtMOgtD+jLVlTpgv3JC0WS2bLE5mgJKRZVP6F6s0S+DAjJb+a5b485JolKRGTM3FRIaGodg7o4CcE/ijcHpOYV6VTSVF1ZxA6T7bak0fXvC2n/o8JufGqhMJExOQDaWXsQJPSqbP6sIWN1UJYkZT2T2QcGhgyOe8ItV99arPu4YeUVnPG6sfasXkFEdSV3KYSwRdH2Ydnp6ASct3ppPlcamgzmOFegqbJ/cfRPr9iJage4xqLzJDl51NJA2RWyUoKTy2az60ciEtsk5UG8BliJFnJGUlWCgx2yUrZypA/c3MCZvBMVkInkpWS1etQeENHkGSl7UTY5LqjRQy6ezf0/UIN8YSOIMMWR4pwPEHH4C3ogmpJG/T4rg/zTlZqwdxsoLaTraAy9fcJ9B0Gvh4PYIsI6khWi01o1njL3JIdQQR1J96wf1BE0MBQFDp06XhK46rXD6XyudXl7IzxgL6gaTS+4P2Tnta8MssypyiPC/2k5LO6J3VBBeZIyA0METQwqhMLKnvKxk7fitApKma1+kxRynHJ6H9G11aCJOQGhggaGOwm5/U3GiMqbzMzc5und3UJVoIWbvUR/BHTNV+oX8Gmo8gt5B7CrMbKIMf9aZwztIHmm83O/WmcF2gBm+nQUrJShPZJKJaObLxL0st1xW+yUlRkLuxEBHWHd7LSJoPztpklF1M005mqg/+njCW2yUrDTVVem8CzJrkos2joygOcrNj09zrNAc3ndWyTlfpbf15LLio8NgO4IslKzjSTrKTxp3bGhB95AMcBcBm2fLRbqKo/1uSCUC09xz61tGq3EBxxSVZ6sWkvis7NznJLivYihvApZNgSGCJoYIiggSGCBka1U0Q9TX23ttxJqcypSdJB0+SG4dX11l4j7wm/H7bxOtZck9M9EaN1YEjIDQwRNDDqbeiEJBajNS/icnJVVdAe5vJEa17UM8gl5AaGCBoYRtDyMpcsefEm7a2yoPMlsRkEbkwLO2tqOrX/AOHPO9NR80/6AAAAAElFTkSuQmCC";
const _imports_2 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAzxSURBVHgB7V3ddds4Fr5U5n01FSxTwcgVhK7ATgUjVxC7gB1Le/Y9dgUjVxBvBVEqiKaCMBVE+74RB/fikrwgQRIEKRrMzHeOLYoiQBAfcP/wwwhmjmwL7+AEG/66i7ZwBzNGBDNGtoE1ZPC7eRK20b8LgmaHBcwZGdzXzkXwThG1hJlitoRQ7wCI+Wuq/vZ8vFQi7BZmitmKrOwevkBOyIJE11f195F/Pqonex1t1OfMMMseUu0d0T08qcrfww/QS+YpsqTuWAgFHsFWHM9Sl8xGZKnKjQFbfga/qs+89afKzH1tXCdFmTKD1RM+0XUb0jPBI0hCsn8pkbSAXwCoha8AmIwqlO5AcWWktZnCJQ6ABkAEf8D/4RD9B54hMARHiGrhn0GT0IWD6h0XDXmgck+gG0jORUjKfzQdgiJF/SUwACr9NTSRgVZUpFp0Bo9KYd+o48umfBRRl+r3G7oW02CPsCNWf2sYVuYVi9NR8BOMANUif1cPv+ZjbHWXnjI7FsdHVfF38Ar2PnmpNLvqOaw8ukcGH8RpL8VPJKCZnekyq+d+GCNsM7iHsAm6FqfiFhnehb04XqrSvQMYVZykFu/eT4/ofGJx5jb7bXjIZrjIsoUvlPz2EV+qVR9I1JRYYSscQySQCawdx1IkYtxrQ4q+b14x2ETdCKb2IEJq4QvpB9iJ6gSJmpFJsZIRwZ13EFI+W0SiMeVvgx3SQVaWJXzxX/X3BXK5rHXJHjxgMV+9dFMDGTc2HeOYX8zPmOeFflAiynpUuuRn8IR3D2kIX2AM6bG8yK+XIERPyXWIn27SaUYhg/Mzegc2EM4v5bNLNUbzK3jCX2Q1hS8AHsSxly7JwaSgeXsU+cWu6VmeX5cZDiPDojtkqKY8PvkrdyeRxQ8Ww3fV0l5RS0UvOn/QevjiN6rIvJWkFL74rj5fUSs69HXEDGcxgp9d07O4+sZfe4uSIlyDz60jB4koB/aOm0o5ZdjmOY8IKOciBR2+6Sx31PggJ2VyRlTpmowm2MMXppytAwuWhzG2bXphcKXKStIh+bTlXmhAoKndHK7JYcmrI2yDyJ8brclHW1nsIitTLTKibpcXDBque6qSQWXdUEW3OUn4oAkAPcBndtiaIM3UP6A/Dta8KigcPS2SVtBOxp2tMlnEPkIz8ue+FWM3Bn6yFCzJvU8BVNZf1SeKjq8sfjCW1GjDq8I9qLzQ6VqptP9UaV5Ttz+pT/wuC3miSmgyF2UlHhrKe6Vvaml1EQ1c5YihGbdQJQHDNQt6Znz+A30Hihw0ih71222m9VTMZddB0qxGMoWaqlZoV+gEC/LW13Tlykmr57k1fga3sEVcHC3KvDiP+zxko0+qyrinVirFoCTxF3DDkUzsbX+nEcHOJv4ZUQBuPB/b0tpElpbtGsjshw6R0gtCNCxFKR6aExiVeECdoir9PeuotSUFisEvGF9jpXwQebU9x04c588dw0hg/SRjaKmtodcIYV8CTc1UFO7jGKQIMuLyhmSKpi3JpA65YiJM8YbeclbTZUQMK+kcMTTAEraJRwzbrCqNMG2KVi8aCpeOTYqFjKOHX2DK+Qg+sbVzo8Iga/KabcSUaBWRrJTfgumMDg3bWMloaoSLlsKNRkoDGZdOZNisFk0Epk/kg5HX3EwM0PhI1+025D9IZ9SblL5k0P2hO1NbZfaaYlMZwcvJcFaYqgzYM65AV9Kjq5HBUQIUWVghn1S6DTjCUpl7GvhyT1+tN6dYnKunblpFPYOG2b0wPPWQqZf1MjWYlM/5d0WIU31xWmlROZGBcIplcUayEp17R1Eg/7QviVQc921E8jmPLmQg+gQXC93h0cKdvOUAIaPEX6EHKnUUOyZzI4QVeS5L+4sb82FimA9aowQOSPlz6WoUuE5yiIsjS0theYnheLTEnhXNT5Uu6uMtd4IaynfDTzliZHVEHRWL40Pl3nkAdg1Y8QsV/a3G9dAaLMNQK4BuseVKiLWlFERkYswjIkW4VoM0G1FAV2+5E3xPDO1fq89lrY9nZESg/Ebz9ck37MN5ycaT8v01ESpMo/LPpUasziXqvhscGxLPnYr0MTjAzcq6J5f/mlNox0n3iKQjaUqDV3po1zuETmXYFCOGCfRDNbblfs97KjNVOlpYYrXWsiPpngeslkW4xDJ+YoMrIXI2YQpgjQY/QjnNpvp7CvohcrP5dZ8Kogl0mgyzIvQEOB2B1sAo8kWlZevyfVfefI+po5UxnSP/xZX7f1L/NwBFr40r2eD9rvm4NpBng6vIkiZcbJzXRDwIR3HHAzWSmLglv1bQ+PTJ8Oht9zTTbEiEbMSo5VINF3xQea1t4zcNkHmXjUkjrYimPYfc1xw7y6+9LgvlZqW5OobSydGF7agUTreu9ZgeawAt9z3wcEDqmD62BDMve3j6GzAnahxZ/D203tNsDPl930ab7h7ax/OMAShO9A11Qk+RswZdKfselVGtzANXZi/H0jINKIUeE6yLsuvnfuqRLgasrxMZHjtXy8+ZkKlB84XLSG2vSqzlpUlBXRPrE+Gu1A2SkIpCHSX+VRF/wa5BDHVJW1IcRSQeBzt6tTWIA5chnAthEpIZCnEHjkA/AYd3G8MU5qzKKwgQo6wPOQOkN793SUDK98TWj44G2MYu9g33CAbB9RCeJVmMsLnI+WIGSonENoWV80r563Lo0oFzIESRJSvJhYxVzdegH2jWSVeF/01IL2Twv9aftxTkM4dJzbHw9zAzhKpDWlFEmU+GWMonZcTCvF0rJb+EhqmfIWIWhLDoWSkC3tD4Q2YN8q3zmZLq+q3QKRiYXOFwgPr8JEb3g0RwjmHNKbRHl3M0xpYscag6ekadp8Ac9jqJLeeICK5Qa6CPpvxEtLFACjPCXHTIkcY+TspjX8Cza4CSPfzXHCC84pHN4CwribAJQZm/gOuhMSeeIbmjLM1VTsEheJEVYgDwnJj3nos/IMImJIJ/wF8MofeQoBXwORAcIRW/4ByExA33CgKh9pB8QGppi9r6orK2ZfCg1zkQJiE6FKJxGo8QY3lbJu4REELtIeV0mZF2F+VRxKQ4sXAfiZwSQRJSG/8esIlNATk/LKPVVH+LrF6Qm7no3dq8SVGRXky7Lk4swpzggAiWEOolclJCBBsfUogMuTtP5jfxeioEO1EuR2VnIQQS1bW2Xa5ZSYqTEQUm30LACJ4QhIUUxB4jv7whTcrncHTwjeoROMk5MTOBJ3X9beixsVkQgnAacGqCHsJ9gBkgfJFV7vazBn/PPQUt6oatqJoA4U62tukA64W0hRKKoW+WrZ9swEGuhx7rRCZFiGPqbURgxeersHBtyl1DHi7iLQX/HbjPhmDMXrHtktyGA3EEvYc77udeEoALS5s8eDk3eEFrWi5A732SiqtoMsUQ/+YcCKKH8EwTXBwpg3/WVVrGEKxlnUdl30NjXV+xiKa+HjCY3vLihFg2eSF/Qf2/sZmolQqnHe/MC+i3mI4X9jWFDcvOUl529qIhlRclxEJGvofWc2s6t/eDdK56ZXLfV+5/+ZKkvJgOadhL6iJyWBgJkYOFFDntjbWrzN0abfc8X7wIIUJnOG/sZWagvPES6F/sQG+Kvy/Onhx3TmjeqM0p/diYnBCxKjbmUz4KVe7Sc0db/G3orTt34vwbx7zaSJl8TH/6HmKuW+9NRjHxWuMo5T0f54bAqk+FClLkcobJTeJJCeHx8dvihEPU1gK5+49tp+uD9VoHMCnSarsdc0zfBdP2ELkveua+d2IFSXG0sKQ3x+OvoSdq4zATL/qZjJCs+jaehffbbUyFXkd5LvLem2sDUvQNeB9IX0zXQyrvGxkwLtE1lcdbZOWI9GbSpYFwmm7IdxJCWA7H/DX1jbRWtxq0kcrn5LwuX1J2YL5IJoEJME0PkcG+bFDYOxH5NM+riozfEvCF1CUe+sgHU4msRNxxB76Q+mPRahBIsTVkj8ddcRRNo0fOTkiWv11T4zAwotqlP3LsywIMegdWCiOIvz6YoockxdGA6Zscyoj5a9q6f/rGXK8+KAwylvhzxBSExOJue/CHDJe4vPpoL44T8EfZE08DiHXE+QkxN6T0NXURscjzijfot99yy9vI2tL2R1ocLX4EQkyk4I+dkV550LbhV56puKvccwf+SMU9uyZQDMa0ImsAovLNP6UIqUwvrU0b1fs0Xow4NHv26O+s9jrBilWi6pJjYlokISn3XFEnI3D5DA3DwCFjdpvPcAW/zXAmYrkAx9QnuHvoNtwZ7m2Y7bLoaEN7r29rP+iZKGuYKWZLCIL3MylJCXj7V1fMmhAEk3JJynvmZCBmuYFZFaFPoO6DaQnRb+BsA04bfVAtncQQm7GosCefbFAgg0kRmsjCBTelxeT2ro4pcXYT+vyEOExYM5AZ6wr7pT0vjvRimjPjTwMwakMM9lUiAAAAAElFTkSuQmCC";
const _imports_3 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAA5YSURBVHgB7V3teds4Eh4qud8rV7B0BWtXELqC1VYQpYLYDazp3P23U8EqFcSpYJUKrK0gTAXW/b5YuBlgSA5AAPyQZMsO3+dRQpMgCGKA+cJgCDBixIgRzwYJ7BAqhxOs8Q1s8H+AKf5OxOU1/1YwgQIUfE1yPB5hYWuCaCJs4Hes6RwMEfqgwN8S771C4hQwYjhBkBAZjvJLPMxgN1iMhBlAECTElAlxHqjxH/z3Dv9fYbkZ/jI+f4u/JTzAMbIsIuZvgUf81ITpRRDNnhR8xsPUqeUr/j7jtU/YkWtRfoHn3nIZ6uRcXKM6ylmWOo8qsPwfz03G6MFq3iXGuovYYHsNXR92hR27wQ52KseOe4cPWEJPcKMW9MMXmTuESfHvOzx/geVu4LkA2wzNwdUsFnmvCXQAEuOyQQwa8VdwPIQYLrCOBdVFddoPhmv1pybUwUPL1A7E0NggKw+glSBIjPdYQS5OrbHjziT7ieAeO/W7/iV43AJdZwKn9knI9ex8bijfu/xBzcpjiLIsVmndqTVlubCEFmAHX+B/F9AHCgeAi41ma/88I5lSJB9wxgswW/6r7cbgDNFC1whwH+bqsr3yvuA65+JUPaqwLSw0XzTCLMvVfoiVoBYlrn+HXUMJrY+ehZqWuJpym140vCyLZ8e8PqEFOLGLOQpZAk3JHFpgzTKjxhax8lhnWb8+5jquBCHO8e8vu1AkDhV+GWKPRKvzy47qBFOP8WdttCF53naLWz8JemRlJLNSUecSXigaLIsNtrkokcMAML+v1bsE3g6WAWjriL8yrWy8UDRliDs7LoXc6AcihiQAHc9hAJhFLasTET3+ucPHsrLqaODs0FAe20GhVxgGWt4JfBF+MVKNc9gTeCa3zsJ9yLKJ0xBqRFqfQB/VAFR+qiayLVTXhTie7ottsSJyh7+/235Y9hx2DJdlZeJ4tYXHdS6OC7DZzaCXYKelNAwz2A9S6OoCgaDHejBcgqTV0cDZwfe+FU/ItTe4ROKxxLsisdq0887wYqALZCgmzsN/E1cKGICGk80QVsqNKZcZgkIcH8H+QSp/Kn84KD7CHuEK9Zq/owBG/V+OwjUah+1+KTk7aN38ynQi1rWEks0YLWnZWpXrnlEWoR9nhjwywgRp8ugCujkK0+rolejQBNXnWkt6A90wh58MndZDeqLmsQ/C47mBX6tjBf+FEV7E3O+3vD5eopswo3sUG24JXCLb+ZXvnYtS3dzozQUrYlOzXu15ZnAJQh2V6qNEx00NMeLoHtKkSvY3d64XOC871esugmm9vyT2C51lNstKrJccJDS1vYArigBeLW3dxesbQSqOn8tiVS+4MqR+STXcEtYre0QUcgomOqxngU86x/+Pt1r1U0IZmAwm6kHDZVlLcXxCbg4Z1tMHMqoEdgB2achBsoQXCIsgNHpRCBMBJP8f5gzcPTJxXHSZaTpiJWk1QomNXhxKYF5TyyJLtHTBb+Od3TXkskDSwag0oa45dMFGu0R27igcAp8dciuOsy3cHDuDjtiwBfpVh9tS6IoJ/AIHggZBmBUsqxNq99ElvWHPjkVv9qLQNtqggiF/iTXwDgZ+wzDRgQUZ/5UiL87LdXXtX1La6dZllPZG6b9CH5hetuWoyVQUGfLcdfJvW7ngNZuDW3n0EoRWwrDBH6ugNbK4aXXMOA7nFKxD0SG7JoqMy1KXYOSZjJocMjueGWK+rBykcWfCeebi+jHsGjIuC3Sk3534uwDYz6w8JAQJwha3DFSTrvlPvcKBOkLXqQJBFdtZ+M8GUW8vW9zvPHftTxWeaF5vG6PGTniRrhIXSZdCipx8bhin0oJ+tzLEGHK585yrLlGSuigFPjywNT/RbpY5XypQFtltnWgbqxTqS7xuZuZr9E7XcmuNxxc7us/fHoUKx39qja8TQQAqT+u1c5o8t/kWsVtl3Rmr16l1wWwGWkBHeAfO4aPQe2MYnQlCCG5pY8LwVueiY11Timbk5dysUd+ALW0/HUEIWn/f6EiS0CYaY1iSN/Z/6JJ4zfLgBxLgX3pap2AI4PcmK1R1adYNcGqyRf/cNveQX66S070JUqIDYfrBhPjkLzmyvQsGE6SEIAwJrRT6Yc1hNbc/ixbVhq0JIlGl1jB70WnF8QiJVdsvE23orXkP+5haY8SIESNGjBgxYsSIESNGjBgxYsSIESNGjBjxGNjFAhWticc297yYaMNGpiQXCXzbNuCjc5pYHzha5HNLMVri3X2U41OAcpzEVkWV7pPv2yxD9yIIjRBntKcdbkudOvQKoi+IgXdJfSv/Tq7qGawu9XlTl8mKuuR7FuBJ1mwlnaTVyQ8msiX2DLednjam0I7Ufac+HKJb3l5sHHYIZcD5Fkl+WVT7CQOh/hxG9A1/94ecj1dH3FMbcRAwm2qC0kWV7wvewSX77K5rFqTWGcK53mmqlnJizpHpF9YmTIVTtdxC4IT667y7Su9fp3qm/EL5PiLotwVvf8j5z5TTMP0B5jMcEuflyMf+SKGMLaOUJLmOGaCBW/bZCddz1hbeFJ0hHmKUIHZwD4FkANzQ+sEbzVYowMEeJYYol9Z9ic5wbX522TNxXgZHnIvzMub4tjo/qdsZe4ZDjBImf5adv9jO325nKZrxu7p9VhIlOlOCWlaAGCvwa1QF8/VC3D+LCHwql9YP232ccF94iCE3v9owUZUVW+a+8ud9N5kt5J7/FfeVd6Z4Z4iXGCZV7CnY6YkKvdsqgVNXcOkG0wi0txeYLQ5uYgFnpjw2PMSg9zoFsx2j4HNrHVVp3tWSkbx145R3CljlExMaJQdbdKaENIxaQzGlbjhtuCzTS3twy1ep9OQoTOBo6L74oeDBJ/PS+2Z7CrQtrmPbfOUVpSmRadQT/xcSuqm9CmaU0Fg+wEcMpvrUd81zjmafHCXFYxNDQLKnFH7othXlxdi7godQbnkefL9bFQQ+TuBlWXoLgD3N0lCuRHoYahnX+LvXI82oeUqrerGvGthbGwpmY48OkZul7tRXftVeq7J/6gxHf5fvWqnHaA4EVWSzB76+Ruw/YNFHXSf48EUVTC2Mq+q6+ZTFDcThZwHCOGO+vIInBNtId6JNx06bQ1sxnIqaCoomIFTJ2xrsXyJuGCYi6dhEdCBUgrCNGAQtK5y0rmuwjakMnh6W9ugZQHG3SXWjR0FJxIcLWpL6WDOEO5mm19RTUrorbKFf5sDib1Dxd0fOwd6qUPBMWHMdtpCzy53t2yEZ7WSz/bras2G5bcx1mgHaaVqlVG9+TUL2V8bPAs+zLOFuz5BNIz14iSLJrewOVjpy3dGXWsXTnU3sR++odT83YcuhBfiRwuPkWpxDeMRXLKeR1sPYIHk5YOidWebaqryyDN4lhLIXOYPSZVm+mfFVCtxG9uuIkcO2yJUo+0ZcWzl6/iGABPw7a3baqurCtUGqS8YD8E6cyiw2bXKHLaEFYRliDDiyCzKHfWSisV32FC7AbmRFdHo5/hgYGZBf4KlgHIXH2JajpLnJVPL8aM5ez0w4EdeIy5D75wh8W80ZMaEeMoTkBpxv0AIPwabeMpMnTWp5H7A1Uvl3J00wsb48lDYumz4tAncPShMrO641u7THRfCUHd8XVls7udCVleqp97u+jlR8rbPLTZBv2kbMSpR5o9rTAM7EceG4E6Yo6N9DorWQqDq4VyhkpcZWILn2UQrsPhn2WHPLxKmVc32uLXYVVp9jM4Q6KNOfrLP1anpI2alTiOwL5wZ6M8FVHlKTuSEDeNIvsKXchvOG4y+xPoT2PjpLjJpfXrc0U170IlOBBmhw8LkEKcD/oNxaerU9vufanZA3li4zj54vLdgZQHA1rlU27QAheeCq5zfWNWPkpvIGXh28tjzGwstd7VT2wU5W3XSd6HWMB6byRPubpvyAKudIYK2EZs2S/0/Btb6dnCXOGvktPtNoWa8cm2eP0IPmoWpDJgxZK7tCIK3IEswApv7JwHWUhu+386680lvCa6ctxBt8I5KY0efqZuJad3eCS4zD9GW5bXJ9WTl0S9uxAieVlOXLakmmE/vS5wnY35Gy3MVar64/KFx4K2Gj0tMA25eltKf0yWQIz3h3ddN1qedgL0BBo7xZrGu6faQqnGg5FJQhoQUq3+LRccwI1NM/waVKharwA5Z7pT+ZtIqUd31ZSyTwk7jgrRGsT6Cm9SGcNrZKkKC0kXevAzjMJ6LWgfKZ48sqP/Dc6J8QQezp2SNnVR/QmgmA5V443rdTsdEGl1VRx145X6zexXPcZWIRQyYRIsiJFbIjKMrUNl/eVCiMJ1q2FBBqiCwv9HzPOvZeOqILPDNEr2lYdpJxon6KKRyiPA2yNXd6EejPU+/KaqTyZiUK2UzimSm+RRkz8v4CXy4sk6xZsoRoJMa+EdAaSd31qebe5YFACJFx1Svr8x1BdmWKxxvqEiWMCcylRY+jjoTkDNrxpMQoocIxaD5Y8k51/FY6tBCDkEB7Q31EMcahEh8NFmpxI5LDBJKtPAtSFjGEKm1uk7r8pVCxRbY5vOcayo+84CIZrcvw+Vml+6OHoFxwij4jRBQTLmq7RUSEjMPy1mA+PS6t9rLPztrU+9aoE5YbZ4IoUp4UUAc0/6rlBYGMrYlVR8YvvBbKQmhmpIGmpOKafNGj6ryynJ3T6vymEX2fAnjfdS3e9YTrpHi0XB+S86NGpsq2K0sbvcDyCw4Cb/QZtKBTGBB3PgncOYT3e5xUI28SrCdXZiHnl3K5Fw4MFVGI3f6wM4ZaaNmG4fRZ5wRtnbcjMBFy2BKeBSCJMiTHc6O1qCNf7oZZCqEQ55dVXYlF+PAz6jZS+QX42tcuT9eingJ69lmrDImB1bwFxAThRIe93MALgDJ2w8zKkidhPsM0O8SZP2LEiBF7wP8Ba91o9iPBzBsAAAAASUVORK5CYII=";
const _sfc_main$e = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "garanties" }, _attrs))} data-v-88acc144><div class="garanties-wrapp container" data-v-88acc144><div class="garanties-title" data-v-88acc144><h2 data-v-88acc144>Мы гарантируем вам</h2></div><div class="garanties-cards" data-v-88acc144><div class="cards-wrapp" data-v-88acc144><div class="card" data-v-88acc144><div class="card-title" data-v-88acc144><img${ssrRenderAttr("src", _imports_0$1)} alt="Качество" data-v-88acc144><h4 data-v-88acc144>Качество</h4></div><div class="card-description" data-v-88acc144><p data-v-88acc144>Мы гарантируем качество нашей продукции и услуг</p></div></div><div class="card" data-v-88acc144><div class="card-title" data-v-88acc144><img${ssrRenderAttr("src", _imports_1)} alt="Ассортимент" data-v-88acc144><h4 data-v-88acc144>Ассортимент</h4></div><div class="card-description" data-v-88acc144><p data-v-88acc144>Мы предлагаем клиентам широкий выбор товара</p></div></div><div class="card" data-v-88acc144><div class="card-title" data-v-88acc144><img${ssrRenderAttr("src", _imports_2)} alt="Опыт" data-v-88acc144><h4 data-v-88acc144>Опыт</h4></div><div class="card-description" data-v-88acc144><p data-v-88acc144>Наш опыт работы позволяет выполнять работу в лучшем виде</p></div></div><div class="card" data-v-88acc144><div class="card-title" data-v-88acc144><img${ssrRenderAttr("src", _imports_3)} alt="Эффективность" data-v-88acc144><h4 data-v-88acc144>Эффективность</h4></div><div class="card-description" data-v-88acc144><p data-v-88acc144>Выполняем работу в кратчайшие сроки</p></div></div></div></div></div></div>`);
}
const _sfc_setup$e = _sfc_main$e.setup;
_sfc_main$e.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/AboutUs/components/AboutGaranties.vue");
  return _sfc_setup$e ? _sfc_setup$e(props, ctx) : void 0;
};
const AboutGaranties = /* @__PURE__ */ _export_sfc(_sfc_main$e, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-88acc144"]]);
const _sfc_main$d = {
  __name: "AboutUsPage",
  __ssrInlineRender: true,
  props: {
    parentCategories: {
      type: Array,
      default: () => []
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(NavBar, { parentCategories: __props.parentCategories }, null, _parent));
      _push(`<section class="about-title" data-v-e9ebd7ac>`);
      _push(ssrRenderComponent(AboutTitle, null, null, _parent));
      _push(`</section><section class="about-pluses" data-v-e9ebd7ac>`);
      _push(ssrRenderComponent(AboutPluses, { backgroundColor: "var(--primary-dark-gray)" }, null, _parent));
      _push(`</section><section class="garanties" data-v-e9ebd7ac>`);
      _push(ssrRenderComponent(AboutGaranties, null, null, _parent));
      _push(`</section><section class="consultation" data-v-e9ebd7ac>`);
      _push(ssrRenderComponent(ConsultationRequest, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Оставьте заявку на консультацию`);
          } else {
            return [
              createTextVNode("Оставьте заявку на консультацию")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section>`);
      _push(ssrRenderComponent(FooterComp, { parentCategories: __props.parentCategories }, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$d = _sfc_main$d.setup;
_sfc_main$d.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/AboutUs/AboutUsPage.vue");
  return _sfc_setup$d ? _sfc_setup$d(props, ctx) : void 0;
};
const AboutUsPage = /* @__PURE__ */ _export_sfc(_sfc_main$d, [["__scopeId", "data-v-e9ebd7ac"]]);
const _sfc_main$c = {
  __name: "ContactTitle",
  __ssrInlineRender: true,
  setup(__props) {
    const isLoading = ref(false);
    const showToast = ref(false);
    const toastMessage = ref("");
    const toastSuccess = ref(false);
    const contactItems = [
      {
        icon: "/src/assets/img/position.svg",
        title: "Адрес",
        texts: ["г. Ижевск"]
      },
      {
        icon: "/src/assets/img/telephone.svg",
        title: "Телефон",
        texts: ["+7(1234)-56-78-90", "+7(1234)-56-78-90"]
      },
      {
        icon: "/src/assets/img/email.svg",
        title: "Email",
        texts: ["pochta@gmail.com"]
      },
      {
        icon: "/src/assets/img/clock.svg",
        title: "Режим работы",
        texts: ["Пн-Пт с 9:00 до 19:00"]
      }
    ];
    const form = ref({
      name: "",
      phone: "",
      email: "",
      message: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "contact-title" }, _attrs))} data-v-bad42d78>`);
      if (showToast.value) {
        _push(`<div class="${ssrRenderClass([{ success: toastSuccess.value }, "toast"])}" data-v-bad42d78>${ssrInterpolate(toastMessage.value)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="container contact-wrapp" data-v-bad42d78><div class="contact-info" data-v-bad42d78><!--[-->`);
      ssrRenderList(contactItems, (item, index) => {
        _push(`<div class="info-item" data-v-bad42d78><div class="item-img" data-v-bad42d78><img${ssrRenderAttr("src", item.icon)}${ssrRenderAttr("alt", item.title)} data-v-bad42d78></div><div class="item-text" data-v-bad42d78><h5 data-v-bad42d78>${ssrInterpolate(item.title)}</h5><!--[-->`);
        ssrRenderList(item.texts, (text, i) => {
          _push(`<p data-v-bad42d78>${ssrInterpolate(text)}</p>`);
        });
        _push(`<!--]--></div></div>`);
      });
      _push(`<!--]--></div><div class="contact-form" data-v-bad42d78><form data-v-bad42d78><div class="input-group" data-v-bad42d78><input required type="text" placeholder="Ваше имя"${ssrRenderAttr("value", form.value.name)} data-v-bad42d78></div><div class="input-group" data-v-bad42d78><input required type="tel" placeholder="Телефон"${ssrRenderAttr("value", form.value.phone)} data-v-bad42d78></div><div class="input-group" data-v-bad42d78><input required type="email" placeholder="Email"${ssrRenderAttr("value", form.value.email)} pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,}$" data-v-bad42d78></div><div class="input-group" data-v-bad42d78><textarea placeholder="Комментарий" data-v-bad42d78>${ssrInterpolate(form.value.message)}</textarea></div><div class="button-group" data-v-bad42d78>`);
      _push(ssrRenderComponent(ButtonComp, {
        class: "submit-btn",
        disabled: isLoading.value
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (!isLoading.value) {
              _push2(`<span data-v-bad42d78${_scopeId}>Отправить</span>`);
            } else {
              _push2(`<span class="loader" data-v-bad42d78${_scopeId}></span>`);
            }
          } else {
            return [
              !isLoading.value ? (openBlock(), createBlock("span", { key: 0 }, "Отправить")) : (openBlock(), createBlock("span", {
                key: 1,
                class: "loader"
              }))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<span class="consent-text" data-v-bad42d78> Оставляя заявку вы соглашаетесь с политикой обработки <a href="#" data-v-bad42d78>персональных данных</a></span></div></form></div></div></div>`);
    };
  }
};
const _sfc_setup$c = _sfc_main$c.setup;
_sfc_main$c.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/ContactsPage/components/ContactTitle.vue");
  return _sfc_setup$c ? _sfc_setup$c(props, ctx) : void 0;
};
const ContactTitle = /* @__PURE__ */ _export_sfc(_sfc_main$c, [["__scopeId", "data-v-bad42d78"]]);
const _sfc_main$b = {
  __name: "ContactsPage",
  __ssrInlineRender: true,
  props: {
    parentCategories: {
      type: Array,
      default: () => []
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(NavBar, { parentCategories: __props.parentCategories }, null, _parent));
      _push(`<section class="title" data-v-77b46cc1>`);
      _push(ssrRenderComponent(ContactTitle, null, null, _parent));
      _push(`</section><section class="contact-map" data-v-77b46cc1><div class="map-container container" data-v-77b46cc1><iframe src="https://yandex.ru/map-widget/v1/?ll=53.191790%2C56.852042&amp;mode=poi&amp;poi%5Bpoint%5D=53.209337%2C56.852042&amp;poi%5Buri%5D=ymapsbm1%3A%2F%2Forg%3Foid%3D1046381508&amp;z=14" width="100%" height="500" frameborder="0" allowfullscreen="true" aria-hidden="false" tabindex="0" data-v-77b46cc1></iframe><div class="map-attribution" data-v-77b46cc1><a href="https://yandex.ru/maps/org/gosudarstvenny_teatr_opery_i_baleta_udmurtskoy_respubliki_imeni_p_i_chaykovskogo/1046381508/?utm_medium=mapframe&amp;utm_source=maps" target="_blank" rel="noopener noreferrer" data-v-77b46cc1> Государственный театр оперы и балета Удмуртской Республики имени П.И. Чайковского </a><a href="https://yandex.ru/maps/44/izhevsk/category/theatre/184105872/?utm_medium=mapframe&amp;utm_source=maps" target="_blank" rel="noopener noreferrer" data-v-77b46cc1> Театр в Ижевске </a></div></div></section><section class="contacts-pluses" data-v-77b46cc1>`);
      _push(ssrRenderComponent(AboutPluses, {
        backgroundColor: "var(--primary-dark-orange)",
        showTitle: false
      }, null, _parent));
      _push(`</section><section class="contacts-consultation" data-v-77b46cc1>`);
      _push(ssrRenderComponent(ConsultationRequest, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Оставьте заявку на консультацию`);
          } else {
            return [
              createTextVNode("Оставьте заявку на консультацию")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section>`);
      _push(ssrRenderComponent(FooterComp, { parentCategories: __props.parentCategories }, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/ContactsPage/ContactsPage.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const ContactsPage = /* @__PURE__ */ _export_sfc(_sfc_main$b, [["__scopeId", "data-v-77b46cc1"]]);
const _sfc_main$a = {
  __name: "CatalogCategories",
  __ssrInlineRender: true,
  props: {
    categories: {
      type: Array,
      default: () => []
    },
    parentCategories: {
      type: Array,
      default: () => []
    }
  },
  emits: ["select-parent", "select-child", "reset"],
  setup(__props, { emit: __emit }) {
    const router = useRouter();
    const route = useRoute();
    const props = __props;
    const mobileMenuOpen = ref(false);
    const isOpen = ref({});
    const selectedParentId = ref(null);
    const closeAllCategories = () => {
      Object.keys(isOpen.value).forEach((key) => {
        isOpen.value[key] = false;
      });
    };
    const emit = __emit;
    onMounted(() => {
      if (route.query.parent) {
        const parentId = parseInt(route.query.parent);
        handleInitialParent(parentId);
      } else if (route.query.child) {
        const childId = parseInt(route.query.child);
        handleInitialChild(childId);
      }
    });
    const handleInitialParent = (parentId) => {
      closeAllCategories();
      selectedParentId.value = parentId;
      isOpen.value[parentId] = true;
    };
    const handleInitialChild = (childId) => {
      const child = props.categories.find((cat) => cat.id === childId);
      if (child && child.parent_id) {
        selectedParentId.value = child.parent_id;
        isOpen.value[child.parent_id] = true;
      }
    };
    const resetSelection = () => {
      router.push({ name: "catalog" });
      selectedParentId.value = null;
      closeAllCategories();
      emit("reset");
    };
    const getChildren = (parentId) => {
      return props.categories.filter((cat) => cat.parent_id === parentId);
    };
    watch(
      () => route.query,
      (newQuery) => {
        if (newQuery.parent) {
          const parentId = parseInt(newQuery.parent);
          if (parentId !== selectedParentId.value) {
            handleInitialParent(parentId);
          }
        } else if (newQuery.child) {
          const childId = parseInt(newQuery.child);
          handleInitialChild(childId);
        } else {
          resetSelection();
        }
      },
      { immediate: true }
    );
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "categories-wrapp" }, _attrs))} data-v-754a11a0><div class="mobile-category-toggle" data-v-754a11a0><h4 data-v-754a11a0>Каталог</h4><svg class="${ssrRenderClass([{ open: mobileMenuOpen.value }, "arrow-icon"])}" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-754a11a0><path d="M1 1.5L6 6.5L11 1.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-v-754a11a0></path></svg></div><div class="${ssrRenderClass([{ "mobile-open": mobileMenuOpen.value }, "categories-list"])}" data-v-754a11a0><!--[-->`);
      ssrRenderList(__props.parentCategories, (parent) => {
        _push(`<div class="categories-item" data-v-754a11a0><div class="${ssrRenderClass([{ open: isOpen.value[parent.id] }, "accordion-header"])}" data-v-754a11a0><span class="${ssrRenderClass({ open: isOpen.value[parent.id] })}" data-v-754a11a0>${ssrInterpolate(parent.name)}</span><svg class="${ssrRenderClass([{ open: isOpen.value[parent.id] }, "arrow-icon"])}" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-754a11a0><path d="M1 1.5L6 6.5L11 1.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-v-754a11a0></path></svg></div>`);
        if (getChildren(parent.id).length) {
          _push(`<ul class="${ssrRenderClass({ open: isOpen.value[parent.id] })}" style="${ssrRenderStyle({ "max-height": isOpen.value[parent.id] ? "500px" : "0" })}" data-v-754a11a0><!--[-->`);
          ssrRenderList(getChildren(parent.id), (child) => {
            _push(`<li data-v-754a11a0>${ssrInterpolate(child.name)}</li>`);
          });
          _push(`<!--]--></ul>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      });
      _push(`<!--]--></div></div>`);
    };
  }
};
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/CatalogPage/components/CatalogCategories.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const CatalogCategories = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["__scopeId", "data-v-754a11a0"]]);
const _imports_0 = "data:image/svg+xml,%3c!--%20icon666.com%20-%20MILLIONS%20OF%20FREE%20VECTOR%20ICONS%20--%3e%3csvg%20version='1.1'%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20512%20512'%20xmlns:xlink='http://www.w3.org/1999/xlink'%20enable-background='new%200%200%20512%20512'%3e%3cg%3e%3cpath%20d='m496.4,243.1c-63.9-78.7-149.3-122.1-240.4-122.1-91.1,0-176.5,43.4-240.4,122.1-6.1,7.5-6.1,18.2%200,25.7%2063.9,78.8%20149.3,122.2%20240.4,122.2%2091.1,0%20176.5-43.4%20240.4-122.1%206.1-7.5%206.1-18.3%200-25.8zm-240.4,79.8c-36.9,0-66.9-30-66.9-66.9%200-36.9%2030-66.9%2066.9-66.9%2036.9,0%2066.9,30%2066.9,66.9%200,36.9-30,66.9-66.9,66.9zm-197.8-66.9c37.8-42.2%2082.9-71.1%20131.5-84.9-25.2,19.7-41.5,50.4-41.5,84.9%200,34.4%2016.2,65.1%2041.5,84.9-48.6-13.8-93.6-42.7-131.5-84.9zm264.1,84.9c25.2-19.7%2041.5-50.4%2041.5-84.9%200-34.4-16.2-65.1-41.5-84.9%2048.6,13.8%2093.7,42.7%20131.5,84.9-37.9,42.2-82.9,71.1-131.5,84.9z'%20fill='%23000000'%20style='fill:%20rgb(255,%20255,%20255);'%3e%3c/path%3e%3c/g%3e%3c/svg%3e";
const _sfc_main$9 = {
  __name: "CatalogProducts",
  __ssrInlineRender: true,
  props: {
    parentCategories: {
      type: Array,
      default: () => []
    },
    categories: {
      type: Array,
      default: () => []
    },
    products: {
      type: Array,
      default: () => []
    }
  },
  emits: ["reset", "view-change"],
  setup(__props, { emit: __emit }) {
    const router = useRouter();
    const route = useRoute();
    const props = __props;
    console.log("PROPS in CatalogProducts:", {
      parentCategories: props.parentCategories,
      categories: props.categories
    });
    const emit = __emit;
    const products = ref([]);
    const childCategories = ref([]);
    const selectedParent = ref(null);
    const selectedCategory = ref(null);
    const currentView = ref("parents");
    const getImageUrl = (imagePath) => {
      if (!imagePath) {
        console.log("Empty image path");
        return "";
      }
      if (imagePath.startsWith("http")) {
        console.log("Absolute image path:", imagePath);
        return imagePath;
      }
      const cleanPath = imagePath.replace(/^\/+/, "");
      const fullUrl = `http://localhost:3000/${cleanPath}`;
      console.log("Generated image URL:", fullUrl);
      return fullUrl;
    };
    const selectParent = async (parent) => {
      selectedParent.value = parent;
      try {
        childCategories.value = await fetchChildCategories(parent.id);
        currentView.value = "subcategories";
        router.push({
          name: "catalog",
          query: { parent: parent.id }
        });
      } catch (error) {
        console.error("Ошибка при загрузке подкатегорий:", error);
      }
    };
    const selectChild = async (child) => {
      selectedCategory.value = child;
      try {
        console.log(
          "All products with categories:",
          props.products.map((p) => ({ id: p.id, name: p.name, category_id: p.category_id }))
        );
        console.log("Current category ID:", child.id);
        products.value = props.products.filter((p) => Number(p.category_id) === Number(child.id));
        console.log("Filtered products:", products.value);
        currentView.value = "products";
        router.push({
          name: "catalog",
          query: {
            parent: child.parent_id,
            child: child.id
          }
        });
      } catch (error) {
        console.error("Ошибка при загрузке товаров:", error);
        products.value = [];
      }
    };
    const resetSelection = () => {
      selectedParent.value = null;
      selectedCategory.value = null;
      currentView.value = "parents";
      emit("reset");
      router.push({ name: "catalog" });
    };
    onMounted(() => {
      if (route.query.child) {
        const childId = parseInt(route.query.child);
        const child = props.categories.find((c) => c.id === childId);
        if (child) {
          selectedCategory.value = child;
          selectChild(child);
        }
      } else if (route.query.parent) {
        const parentId = parseInt(route.query.parent);
        const parent = props.parentCategories.find((p) => p.id === parentId);
        if (parent) {
          selectParent(parent);
        }
      }
    });
    watch(
      () => route.query,
      (newQuery) => {
        if (newQuery.child) {
          const childId = parseInt(newQuery.child);
          const child = props.categories.find((c) => c.id === childId);
          if (child && (!selectedCategory.value || selectedCategory.value.id !== childId)) {
            selectChild(child);
          }
        } else if (newQuery.parent) {
          const parentId = parseInt(newQuery.parent);
          const parent = props.parentCategories.find((p) => p.id === parentId);
          if (parent && (!selectedParent.value || selectedParent.value.id !== parentId)) {
            selectParent(parent);
          }
        } else {
          resetSelection();
        }
      }
    );
    watch(currentView, (newView) => {
      emit("view-change", newView === "products");
    }, { immediate: true });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "products-wrapp" }, _attrs))} data-v-cae05e2f><h4 data-v-cae05e2f>${ssrInterpolate(currentView.value === "products" ? selectedCategory.value.name : currentView.value === "subcategories" ? selectedParent.value.name : "Все категории")}</h4>`);
      if (currentView.value === "parents") {
        _push(`<div class="product-list" data-v-cae05e2f><!--[-->`);
        ssrRenderList(__props.parentCategories, (parent) => {
          _push(`<div class="card" data-v-cae05e2f><div class="card-body" data-v-cae05e2f>`);
          if (parent.image_url) {
            _push(`<img${ssrRenderAttr("src", getImageUrl(parent.image_url))}${ssrRenderAttr("alt", parent.name)} class="product-image" data-v-cae05e2f>`);
          } else {
            _push(`<div class="no-image" data-v-cae05e2f>Нет изображения</div>`);
          }
          _push(`<div class="card-buy" data-v-cae05e2f><img${ssrRenderAttr("src", _imports_0)} alt="Купить" class="cart-icon" data-v-cae05e2f><span class="buy-text" data-v-cae05e2f>Перейти</span></div></div><h5 data-v-cae05e2f>${ssrInterpolate(parent.name)}</h5></div>`);
        });
        _push(`<!--]--></div>`);
      } else if (currentView.value === "subcategories") {
        _push(`<div class="product-list" data-v-cae05e2f><!--[-->`);
        ssrRenderList(childCategories.value, (child) => {
          _push(`<div class="card" data-v-cae05e2f><div class="card-body" data-v-cae05e2f>`);
          if (child.image_url) {
            _push(`<img${ssrRenderAttr("src", getImageUrl(child.image_url))}${ssrRenderAttr("alt", child.name)} class="product-image" data-v-cae05e2f>`);
          } else {
            _push(`<div class="no-image" data-v-cae05e2f>Нет изображения</div>`);
          }
          _push(`<div class="card-buy" data-v-cae05e2f><img${ssrRenderAttr("src", _imports_0)} alt="Купить" class="cart-icon" data-v-cae05e2f><span class="buy-text" data-v-cae05e2f>Перейти</span></div></div><h5 data-v-cae05e2f>${ssrInterpolate(child.name)}</h5></div>`);
        });
        _push(`<!--]--></div>`);
      } else if (currentView.value === "products") {
        _push(`<div class="product-list" data-v-cae05e2f>`);
        if (props.products.length === 0) {
          _push(`<div data-v-cae05e2f><h5 data-v-cae05e2f>Товары не найдены</h5></div>`);
        } else {
          _push(`<!--[-->`);
          ssrRenderList(products.value, (product) => {
            _push(`<div class="card" data-v-cae05e2f><div class="card-body" data-v-cae05e2f>`);
            if (product.image_url) {
              _push(`<img${ssrRenderAttr("src", getImageUrl(product.image_url))}${ssrRenderAttr("alt", product.name)} class="product-image" data-v-cae05e2f>`);
            } else {
              _push(`<div class="no-image" data-v-cae05e2f>Нет изображения</div>`);
            }
            _push(`<div class="card-buy" data-v-cae05e2f><img${ssrRenderAttr("src", _imports_1$4)} alt="Купить" class="cart-icon" data-v-cae05e2f><span class="buy-text" data-v-cae05e2f>Заказать</span></div></div><h5 data-v-cae05e2f>${ssrInterpolate(product.name)}</h5></div>`);
          });
          _push(`<!--]-->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/CatalogPage/components/CatalogProducts.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const CatalogProducts = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["__scopeId", "data-v-cae05e2f"]]);
const _sfc_main$8 = {
  __name: "CatalogPage",
  __ssrInlineRender: true,
  props: {
    parentCategories: {
      type: Array,
      default: () => []
    },
    categories: {
      type: Array,
      default: () => []
    },
    products: {
      type: Array,
      default: () => []
    },
    loading: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    const route = useRoute();
    const selectedCategoryId = ref(null);
    const currentView = ref(null);
    const searchQuery = ref("");
    const searchProducts = (view) => {
      currentView.value = view;
      if (!view) {
        searchQuery.value = "";
      }
    };
    onMounted(() => {
      if (route.query.category) {
        selectedCategoryId.value = parseInt(route.query.category);
      }
    });
    watch(
      () => route.query.category,
      (newCategoryId) => {
        if (newCategoryId) {
          selectedCategoryId.value = parseInt(newCategoryId);
        } else {
          selectedCategoryId.value = null;
        }
      }
    );
    const filteredProducts = computed(() => {
      let filtered = props.products;
      if (selectedCategoryId.value) {
        const childCategoryIds = props.categories.filter((cat) => cat.parent_id === selectedCategoryId.value).map((cat) => cat.id);
        const categoriesToFilter = [selectedCategoryId.value, ...childCategoryIds];
        filtered = filtered.filter(
          (product) => categoriesToFilter.includes(product.category_id)
        );
      }
      if (searchQuery.value.trim()) {
        const firstLetter = searchQuery.value.trim().toLowerCase()[0];
        filtered = filtered.filter((product) => {
          var _a;
          const productName = ((_a = product.name) == null ? void 0 : _a.toLowerCase()) || "";
          return productName.startsWith(firstLetter);
        });
      }
      return filtered;
    });
    watch(searchQuery, () => {
      console.log("Search query changed:", searchQuery.value);
    });
    const props = __props;
    const handleParentSelect = (parent) => {
      selectedCategoryId.value = parent.id;
    };
    const handleChildSelect = (child) => {
      selectedCategoryId.value = child.id;
    };
    const handleReset = () => {
      selectedCategoryId.value = null;
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      if (__props.loading) {
        _push(`<div class="loading-overlay" data-v-bdda1ff8><div class="spinner" data-v-bdda1ff8></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div data-v-bdda1ff8>`);
      _push(ssrRenderComponent(NavBar, { parentCategories: __props.parentCategories }, null, _parent));
      _push(`<section class="catalog" data-v-bdda1ff8><div class="catalog-wrapp container" data-v-bdda1ff8>`);
      if (currentView.value) {
        _push(`<input type="text" placeholder="Поиск товара" class="search-input"${ssrRenderAttr("value", searchQuery.value)} data-v-bdda1ff8>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="categories-wrapp" data-v-bdda1ff8>`);
      _push(ssrRenderComponent(CatalogCategories, {
        categories: __props.categories,
        parentCategories: __props.parentCategories,
        onSelectCategory: _ctx.handleCategorySelect,
        onResetCategory: _ctx.resetCategory
      }, null, _parent));
      _push(`</div><div class="product-wrapp" data-v-bdda1ff8>`);
      _push(ssrRenderComponent(CatalogProducts, {
        "parent-categories": __props.parentCategories,
        categories: __props.categories,
        products: filteredProducts.value,
        onSelectParent: handleParentSelect,
        onSelectChild: handleChildSelect,
        onReset: handleReset,
        onViewChange: searchProducts
      }, null, _parent));
      _push(`</div></div></section>`);
      _push(ssrRenderComponent(FooterComp, { parentCategories: __props.parentCategories }, null, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/CatalogPage/CatalogPage.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const CatalogPage = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["__scopeId", "data-v-bdda1ff8"]]);
const _sfc_main$7 = {
  __name: "ProductCard",
  __ssrInlineRender: true,
  emits: ["scroll-to-consultation"],
  setup(__props, { emit: __emit }) {
    const route = useRoute();
    const product = ref(null);
    const loading = ref(true);
    const cartStore = useCartStore();
    const showNotification = ref(false);
    const emit = __emit;
    const isInCart = computed(() => {
      return product.value ? cartStore.items.some((item) => item.id === product.value.id) : false;
    });
    const handleConsultationClick = () => {
      emit("scroll-to-consultation");
    };
    const getImage = (imageUrl) => {
      return `http://localhost:3000${imageUrl}`;
    };
    const fetchProduct = async () => {
      try {
        loading.value = true;
        product.value = await fetchProductById(route.params.id);
      } catch (error) {
        console.error("Ошибка при загрузке товара:", error);
        product.value = null;
      } finally {
        loading.value = false;
      }
    };
    const toggleCart = () => {
      if (!product.value) return;
      if (isInCart.value) {
        cartStore.removeFromCart(product.value.id);
      } else {
        cartStore.addToCart(product.value);
        showNotification.value = true;
        setTimeout(() => {
          showNotification.value = false;
        }, 3e3);
      }
    };
    onMounted(() => {
      fetchProduct();
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "product-page" }, _attrs))} data-v-fdf8d7e0>`);
      if (loading.value) {
        _push(`<div class="loading" data-v-fdf8d7e0>Загрузка товара...</div>`);
      } else if (product.value) {
        _push(`<div class="product-container" data-v-fdf8d7e0>`);
        if (showNotification.value) {
          _push(`<div class="notification" data-v-fdf8d7e0> Товар добавлен в корзину! </div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="product-gallery" data-v-fdf8d7e0><div class="main-image" data-v-fdf8d7e0><img${ssrRenderAttr("src", getImage(product.value.image_url))}${ssrRenderAttr("alt", product.value.name)} class="product-image" data-v-fdf8d7e0></div></div><div class="product-info" data-v-fdf8d7e0><h1 class="product-title" data-v-fdf8d7e0>${ssrInterpolate(product.value.name)}</h1>`);
        if (product.value.price) {
          _push(`<div class="price-block" data-v-fdf8d7e0><span class="current-price" data-v-fdf8d7e0>${ssrInterpolate(product.value.price)} ₽</span>`);
          if (product.value.old_price) {
            _push(`<span class="old-price" data-v-fdf8d7e0>${ssrInterpolate(product.value.old_price)} ₽</span>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="description-block" data-v-fdf8d7e0><h3 data-v-fdf8d7e0>Описание</h3><p class="product-description" data-v-fdf8d7e0>${ssrInterpolate(product.value.description)}</p></div><div class="action-buttons" data-v-fdf8d7e0>`);
        _push(ssrRenderComponent(ButtonComp, { onClick: handleConsultationClick }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Заказать`);
            } else {
              return [
                createTextVNode("Заказать")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(ButtonComp, {
          variant: "transparent",
          onClick: toggleCart,
          class: { "in-cart": isInCart.value }
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(isInCart.value ? "Удалить из корзины" : "В корзину")}`);
            } else {
              return [
                createTextVNode(toDisplayString(isInCart.value ? "Удалить из корзины" : "В корзину"), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<div class="not-found" data-v-fdf8d7e0><h2 data-v-fdf8d7e0>Товар не найден</h2><p data-v-fdf8d7e0>К сожалению, запрашиваемый товар отсутствует в нашем магазине.</p>`);
        _push(ssrRenderComponent(_component_router_link, {
          to: "/catalog",
          class: "back-link"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`&lt;`);
            } else {
              return [
                createTextVNode("<")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/ProductPage/Components/ProductCard.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const ProductCard = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["__scopeId", "data-v-fdf8d7e0"]]);
const _sfc_main$6 = {
  __name: "ProductPage",
  __ssrInlineRender: true,
  props: {
    parentCategories: {
      type: Array,
      default: () => []
    },
    loading: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    const consultationRef = ref(null);
    const scrollToConsultation = () => {
      var _a;
      (_a = consultationRef.value) == null ? void 0 : _a.scrollIntoView({
        behavior: "smooth",
        block: "start"
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      _push(`<!--[-->`);
      if (__props.loading) {
        _push(`<div class="loading-overlay" data-v-cd5ad095><div class="spinner" data-v-cd5ad095></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div data-v-cd5ad095>`);
      _push(ssrRenderComponent(NavBar, { parentCategories: __props.parentCategories }, null, _parent));
      _push(`<div class="product-wrapp container" data-v-cd5ad095>`);
      _push(ssrRenderComponent(_component_router_link, {
        to: "/catalog",
        class: "back-link"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg class="arrow-icon" width="16" height="10" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-cd5ad095${_scopeId}><path d="M1 1.5L6 6.5L11 1.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" data-v-cd5ad095${_scopeId}></path></svg>`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                class: "arrow-icon",
                width: "16",
                height: "10",
                viewBox: "0 0 12 8",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg"
              }, [
                createVNode("path", {
                  d: "M1 1.5L6 6.5L11 1.5",
                  "stroke-width": "3",
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="product-card" data-v-cd5ad095>`);
      _push(ssrRenderComponent(ProductCard, { onScrollToConsultation: scrollToConsultation }, null, _parent));
      _push(`</div></div><div class="product-consultation" data-v-cd5ad095>`);
      _push(ssrRenderComponent(ConsultationRequest, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Позвоните нам, или оставьте заявку на звонок`);
          } else {
            return [
              createTextVNode("Позвоните нам, или оставьте заявку на звонок")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(FooterComp, { parentCategories: __props.parentCategories }, null, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/ProductPage/ProductPage.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const ProductPage = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["__scopeId", "data-v-cd5ad095"]]);
const _sfc_main$5 = {
  __name: "AdminLogin",
  __ssrInlineRender: true,
  setup(__props) {
    const password = ref("");
    const loading = ref(false);
    const error = ref("");
    useRouter();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_router_link, {
        to: "/",
        class: "back-link"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg class="arrow-icon" width="16" height="10" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-dd20f8e6${_scopeId}><path d="M1 1.5L6 6.5L11 1.5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" data-v-dd20f8e6${_scopeId}></path></svg>`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                class: "arrow-icon",
                width: "16",
                height: "10",
                viewBox: "0 0 12 8",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg"
              }, [
                createVNode("path", {
                  d: "M1 1.5L6 6.5L11 1.5",
                  "stroke-width": "3",
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="admin-login" data-v-dd20f8e6><div class="login-container" data-v-dd20f8e6><h1 data-v-dd20f8e6>Админ логин</h1><form data-v-dd20f8e6><div class="form-group" data-v-dd20f8e6><label for="password" data-v-dd20f8e6>Пароль</label><input type="password" id="password"${ssrRenderAttr("value", password.value)} required placeholder="Введите пароль администратора" data-v-dd20f8e6></div><button type="submit"${ssrIncludeBooleanAttr(loading.value) ? " disabled" : ""} data-v-dd20f8e6>${ssrInterpolate(loading.value ? "Вход..." : "Вход")}</button>`);
      if (error.value) {
        _push(`<p class="error-message" data-v-dd20f8e6>Неверный пароль</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</form></div></div><!--]-->`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/AdminPanel/AdminLogin.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const AdminLogin = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-dd20f8e6"]]);
const AdminLogin$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: AdminLogin
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$4 = {
  __name: "AdminLayout",
  __ssrInlineRender: true,
  setup(__props) {
    useRouter();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      const _component_router_view = resolveComponent("router-view");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "admin-layout" }, _attrs))} data-v-7afb7d5b><header class="admin-header" data-v-7afb7d5b><div class="header-content" data-v-7afb7d5b><h1 data-v-7afb7d5b>Панель администратора</h1><button class="logout-btn" data-v-7afb7d5b>Выход</button></div><nav class="admin-nav" data-v-7afb7d5b>`);
      _push(ssrRenderComponent(_component_router_link, { to: "/admin/dashboard" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Главная`);
          } else {
            return [
              createTextVNode("Главная")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_router_link, { to: "/admin/products" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Товары`);
          } else {
            return [
              createTextVNode("Товары")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_router_link, { to: "/admin/categories" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Категории`);
          } else {
            return [
              createTextVNode("Категории")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_router_link, { to: "/admin/consultations" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Заявки`);
          } else {
            return [
              createTextVNode("Заявки")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</nav></header><main class="admin-main" data-v-7afb7d5b>`);
      _push(ssrRenderComponent(_component_router_view, null, null, _parent));
      _push(`</main></div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/AdminPanel/AdminLayout.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const AdminLayout = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-7afb7d5b"]]);
const AdminLayout$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: AdminLayout
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$3 = {
  __name: "AdminDashboard",
  __ssrInlineRender: true,
  setup(__props) {
    const productsCount = ref(0);
    const categoriesCount = ref(0);
    onMounted(async () => {
      try {
        const products = await fetchProducts();
        const categories = await fetchCategories();
        productsCount.value = products.length;
        categoriesCount.value = categories.length;
      } catch (error) {
        console.error("Failed to fetch data:", error);
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "admin-dashboard" }, _attrs))} data-v-c3e3be0b><h2 data-v-c3e3be0b>Главная</h2><div class="stats" data-v-c3e3be0b><div class="stat-card" data-v-c3e3be0b><h3 data-v-c3e3be0b>Всего товаров</h3><p data-v-c3e3be0b>${ssrInterpolate(productsCount.value)}</p></div><div class="stat-card" data-v-c3e3be0b><h3 data-v-c3e3be0b>Всего категорий</h3><p data-v-c3e3be0b>${ssrInterpolate(categoriesCount.value)}</p></div></div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/AdminPanel/AdminDashboard.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const AdminDashboard = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-c3e3be0b"]]);
const AdminDashboard$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: AdminDashboard
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$2 = {
  __name: "AdminProducts",
  __ssrInlineRender: true,
  setup(__props) {
    const products = ref([]);
    const categories = ref([]);
    const loading = ref(true);
    const deleteLoading = ref({});
    const errorMessage = ref("");
    const showDeleteModal = ref(false);
    const deleteMessage = ref("");
    ref(null);
    const getImageUrl = (imagePath) => {
      if (!imagePath) return "";
      if (imagePath.startsWith("http")) return imagePath;
      return `http://localhost:3000${imagePath.startsWith("/") ? "" : "/"}${imagePath}`;
    };
    onMounted(async () => {
      try {
        const [productsData, categoriesData] = await Promise.all([
          fetchProducts(),
          fetchCategories()
        ]);
        products.value = productsData.map((product) => ({
          ...product,
          fullImageUrl: getImageUrl(product.image_url)
        }));
        categories.value = categoriesData;
      } catch (error) {
        console.error("Ошибка загрузки данных:", error);
        errorMessage.value = "Не удалось загрузить список товаров";
      } finally {
        loading.value = false;
      }
    });
    const getCategoryName = (categoryId) => {
      const category = categories.value.find((c) => c.id === categoryId);
      return category ? category.name : "Неизвестно";
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "admin-products" }, _attrs))} data-v-2c0014e4><div class="header" data-v-2c0014e4><h2 data-v-2c0014e4>Администрирование товаров</h2>`);
      _push(ssrRenderComponent(_component_router_link, {
        to: "/admin/products/new",
        class: "add-btn"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Добавить товар `);
          } else {
            return [
              createTextVNode(" Добавить товар ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      if (loading.value) {
        _push(`<div class="loading" data-v-2c0014e4>Загрузка...</div>`);
      } else {
        _push(`<table class="products-table" data-v-2c0014e4><thead data-v-2c0014e4><tr data-v-2c0014e4><th data-v-2c0014e4>ID</th><th data-v-2c0014e4>Название</th><th data-v-2c0014e4>Категория</th><th data-v-2c0014e4>Фото</th><th data-v-2c0014e4>Действие</th></tr></thead><tbody data-v-2c0014e4><!--[-->`);
        ssrRenderList(products.value, (product) => {
          _push(`<tr data-v-2c0014e4><td data-v-2c0014e4>${ssrInterpolate(product.id)}</td><td data-v-2c0014e4>${ssrInterpolate(product.name)}</td><td data-v-2c0014e4>${ssrInterpolate(getCategoryName(product.category_id))}</td><td data-v-2c0014e4>`);
          if (product.fullImageUrl) {
            _push(`<img${ssrRenderAttr("src", product.fullImageUrl)}${ssrRenderAttr("alt", product.name)} data-v-2c0014e4>`);
          } else {
            _push(`<span data-v-2c0014e4>Нет фото</span>`);
          }
          _push(`</td><td class="actions" data-v-2c0014e4>`);
          _push(ssrRenderComponent(_component_router_link, {
            to: `/admin/products/edit/${product.id}`,
            class: "edit-btn"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(` Редактировать `);
              } else {
                return [
                  createTextVNode(" Редактировать ")
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`<button class="delete-btn"${ssrIncludeBooleanAttr(deleteLoading.value[product.id]) ? " disabled" : ""} data-v-2c0014e4>${ssrInterpolate(deleteLoading.value[product.id] ? "Удаление..." : "Удалить")}</button></td></tr>`);
        });
        _push(`<!--]--></tbody></table>`);
      }
      if (showDeleteModal.value) {
        _push(`<div class="modal-overlay" data-v-2c0014e4><div class="modal-content" data-v-2c0014e4><h3 data-v-2c0014e4>Подтверждение удаления</h3><p data-v-2c0014e4>${ssrInterpolate(deleteMessage.value)}</p><div class="modal-actions" data-v-2c0014e4><button class="confirm-btn" data-v-2c0014e4>Удалить</button><button class="cancel-btn" data-v-2c0014e4>Отмена</button></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/AdminPanel/AdminProducts.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const AdminProducts = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-2c0014e4"]]);
const AdminProducts$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: AdminProducts
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$1 = {
  __name: "PrivacyPolicy",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "privacy-wrapp" }, _attrs))} data-v-5111bec2>`);
      _push(ssrRenderComponent(NavBar, null, null, _parent));
      _push(`<div class="privacy-body container" data-v-5111bec2><h1 data-v-5111bec2>Положение об обработке персональных данных</h1><h2 data-v-5111bec2>1. ОБЩИЕ ПОЛОЖЕНИЯ</h2><p data-v-5111bec2>1.1. Настоящим положением устанавливается порядок обработки персональных данных пользователей сайта https://izhdrill.ru/, принадлежащего «Иждрил Холдинг» (далее – оператор), и обеспечивается соблюдение требований защиты прав граждан при обработке персональных данных.</p><p data-v-5111bec2>1.2. Политика разработана в соответствии с Федеральным законом № 152-ФЗ «О персональных данных» от 27.07.2006 (далее — ФЗ «О персональных данных»).</p><h2 data-v-5111bec2>2. ОСНОВНЫЕ ПОНЯТИЯ, ИСПОЛЬЗУЕМЫЕ В НАСТОЯЩЕМ ПОЛОЖЕНИИ</h2><p data-v-5111bec2>2.1. Для целей настоящего положения используются следующие основные понятия:</p><ul data-v-5111bec2><li data-v-5111bec2> сайт - совокупность программно-аппаратных средств, обеспечивающих публикацию данных в Интернет для всеобщего обозрения. Сайт доступен по уникальному электронному адресу или его буквенному обозначению. Может содержать графическую, текстовую, аудио-, видео-, а также иную информацию, воспроизводимую с помощью компьютера; </li><li data-v-5111bec2> оператор - юридическое или физическое лицо, организующее и (или) осуществляющее обработку персональных данных, а также определяющее цели и содержание обработки персональных данных; </li><li data-v-5111bec2>любая информация, относящаяся к прямо или косвенно определенному или определяемому физическому лицу (субъекту персональных данных);</li><li data-v-5111bec2> субъект персональных данных - физическое лицо, которое прямо или косвенно определено или определяемо с помощью персональных данных. В рамках данного положения субъектом считается физическое лицо, являющееся клиентом - пользователем сайта https://izhdrill.ru/; </li><li data-v-5111bec2> обработка персональных данных - действия (операции) с персональными данными, включая сбор, систематизацию, накопление, хранение, уточнение (обновление, изменение), использование, распространение (в том числе передача), обезличивание, блокирование, уничтожение персональных данных; </li><li data-v-5111bec2> общедоступные персональные данные - персональные данные, доступ неограниченного круга лиц к которым предоставлен с согласия субъекта персональных данных или на которые в соответствии с федеральными законами не распространяется требование соблюдения конфиденциальности. </li></ul><h2 data-v-5111bec2>3. СОСТАВ ПЕРСОНАЛЬНЫХ ДАННЫХ ПОЛЬЗОВАТЕЛЯ</h2><h5 data-v-5111bec2>3.1. Состав персональных данных:</h5><p data-v-5111bec2>Самостоятельно предоставляемые пользователем данные при заполнении формы обратной связи и анкеты клиента:</p><ul data-v-5111bec2><li data-v-5111bec2> имя </li><li data-v-5111bec2> контактная информация (телефон, почта) </li></ul><p data-v-5111bec2>Автоматически собираемые данные:</p><ul data-v-5111bec2><li data-v-5111bec2> IP-адрес, данные файлов cookie; </li><li data-v-5111bec2> информация о браузере пользователя, технические характеристики оборудования и программного обеспечения, используемых пользователем; </li><li data-v-5111bec2> дата и время доступа к сайту, адреса запрашиваемых страниц и иная подобная информация. </li></ul><h5 data-v-5111bec2>3.2. Персональные данные, указанные в пункте 3.1 положения обрабатываются в целях идентификации пользователей, обеспечения исполнения пользовательского соглашения, предоставления пользователю персонализированных сервисов и контента, улучшения качества работы сайта и предоставления сервисов, таргетирования рекламных материалов, проведения на основе обезличенных персональных данных статистических и иных исследований.</h5><h5 data-v-5111bec2>3.3. Обработка персональных данных пользователей производится с их согласия. Пользователь, заполняющий данные в форме обратной связи и анкеты на сайте https://izhdrill.ru/ с целью получения необходимой информации, тем самым выражает свое полное согласие в соответствии со статьей 9 Федерального закона от 27 июля 2006 г. № 152-ФЗ «О персональных данных» на автоматизированную, а также без использования средств автоматизации, обработку и использование своих персональных данных.</h5><h2 data-v-5111bec2>4. КОНФИДЕНЦИАЛЬНОСТЬ ПЕРСОНАЛЬНЫХ ДАННЫХ</h2><h5 data-v-5111bec2>4.1. Сведения, перечисленные в статье 3 настоящего положения, являются конфиденциальными. Оператор обеспечивает конфиденциальность персональных данных и обязан не допускать их распространения без согласия клиентов, либо наличия иного законного основания.</h5><h5 data-v-5111bec2>4.2. Все меры конфиденциальности при сборе, обработке и хранении персональных данных клиентов распространяются как на бумажные, так и на электронные (автоматизированные) носители информации.</h5><h5 data-v-5111bec2>4.3. Режим конфиденциальности персональных данных снимается в случаях обезличивания или опубликования их в общедоступных источниках (СМИ, Интернет, ЕГРЮЛ и иных публичных государственных реестрах).</h5><h2 data-v-5111bec2>5. ПРАВА И ОБЯЗАННОСТИ ОПЕРАТОРА ПЕРСОНАЛЬНЫХ ДАННЫХ</h2><h5 data-v-5111bec2>5.1. Обработка персональных данных пользователей осуществляется оператором с согласия субъектов персональных данных, за исключением случаев, предусмотренных пунктом 5.2 настоящей статьи.</h5><h5 data-v-5111bec2>5.2. Компания имеет право без согласия субъекта персональных данных осуществлять обработку его персональных данных в следующих случаях:</h5><ul data-v-5111bec2><li data-v-5111bec2>Обработка персональных данных осуществляется на основании федерального закона, устанавливающего ее цель, условия получения персональных данных и круг субъектов, персональные данные которых подлежат обработке, а также определяющего полномочия оператора;</li><li data-v-5111bec2>Обработка персональных данных осуществляется в целях исполнения договора, одной из сторон которого является субъект персональных данных;</li><li data-v-5111bec2>Осуществляется обработка персональных данных, подлежащих опубликованию в соответствии с федеральными законами, в том числе персональных данных лиц, замещающих государственные должности, должности государственной гражданской службы, персональных данных кандидатов на выборные государственные или муниципальные должности.</li></ul><h5 data-v-5111bec2>5.3. При определении объема и содержания персональных данных пользователя подлежащих обработке, оператор руководствуется Федеральным законом «О персональных данных», пользовательским соглашением.</h5><h5 data-v-5111bec2>5.4. Оператор обеспечивает защиту персональных данных пользователя от неправомерного их использования или утраты за собственный счет в порядке, установленном федеральным законодательством.</h5><h2 data-v-5111bec2>6. ПРАВА СУБЪЕКТА ПЕРСОНАЛЬНЫХ ДАННЫХ</h2><h5 data-v-5111bec2>6.1. Субъект персональных данных имеет право на получение сведений об операторе, о месте его нахождения, о наличии у оператора персональных данных, относящихся к соответствующему субъекту персональных данных.</h5><h5 data-v-5111bec2>6.2. Сведения о наличии персональных данных должны быть предоставлены субъекту персональных данных оператором в доступной форме, и в них не должны содержаться персональные данные, относящиеся к другим субъектам персональных данных.</h5><h5 data-v-5111bec2>6.3. Доступ к своим персональным данным предоставляется субъекту персональных данных или его законному представителю при обращении либо при получении запроса.</h5><h5 data-v-5111bec2>6.4. Субъект персональных данных имеет право отозвать согласие на обработку персональных данных, ограничить способы и формы обработки персональных данных.</h5><h2 data-v-5111bec2>7. ОБРАБОТКА ПЕРСОНАЛЬНЫХ ДАННЫХ</h2><h5 data-v-5111bec2>7.1. Обработка персональных данных осуществляется оператором исключительно для достижения целей, определенных настоящим положением и пользовательским соглашением.</h5><h5 data-v-5111bec2>7.2. Обработка персональных данных оператором заключается в получении, систематизации, накоплении, хранении, уточнении, использовании, распространении, обезличивании, блокировании, уничтожении и в защите от несанкционированного доступа.</h5><h5 data-v-5111bec2>7.3. Обработка персональных данных ведется методом смешанной обработки.</h5><h2 data-v-5111bec2>8. ПЕРЕДАЧА ПЕРСОНАЛЬНЫХ ДАННЫХ</h2><h5 data-v-5111bec2>8.1. Передача персональных данных осуществляется оператором исключительно в случае необходимости исполнения пользовательского соглашения либо предоставления пользователю определенных сервисов с согласия пользователя.</h5><h5 data-v-5111bec2>8.2. Передача персональных данных третьим лицам осуществляется оператором только на основании соответствующего договора, существенным условием которого является обязанность обеспечения третьим лицом конфиденциальности.</h5><h5 data-v-5111bec2>8.3. Передача персональных данных государственным органам осуществляется в рамках их полномочий в соответствии с применимым законодательством.</h5><h2 data-v-5111bec2>9. ХРАНЕНИЕ ПЕРСОНАЛЬНЫХ ДАННЫХ</h2><h5 data-v-5111bec2>9.1. Персональные данные могут храниться в электронном виде на территории России.</h5><h2 data-v-5111bec2>10. ЗАЩИТА ПЕРСОНАЛЬНЫХ ДАННЫХ ПОЛЬЗОВАТЕЛЕЙ</h2><h5 data-v-5111bec2>10.1. Оператор обязан принимать необходимые организационные и технические меры для защиты персональных данных от неправомерного доступа.</h5><h2 data-v-5111bec2>11. ОТВЕТСТВЕННОСТЬ ЗА РАЗГЛАШЕНИЕ ИНФОРМАЦИИ</h2><h5 data-v-5111bec2>11.1. Сотрудники оператора, виновные в нарушении норм, регулирующих обработку персональных данных, несут ответственность в соответствии с федеральными законами.</h5></div>`);
      _push(ssrRenderComponent(FooterComp, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/PrivacyPolicy.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const PrivacyPolicy = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-5111bec2"]]);
const _sfc_main = {
  __name: "Basket",
  __ssrInlineRender: true,
  setup(__props) {
    const cartStore = useCartStore();
    const consultationRef = ref(null);
    const getImage = (imageUrl) => {
      return `http://localhost:3000${imageUrl}`;
    };
    const scrollToConsultation = () => {
      var _a;
      if ((_a = consultationRef.value) == null ? void 0 : _a.$el) {
        consultationRef.value.$el.scrollIntoView({
          behavior: "smooth",
          block: "start"
        });
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "cart-page" }, _attrs))} data-v-0bb6f940>`);
      _push(ssrRenderComponent(NavBar, null, null, _parent));
      _push(`<div class="container" data-v-0bb6f940><div class="basket-wrapp" data-v-0bb6f940><h1 data-v-0bb6f940>Ваша корзина</h1>`);
      if (unref(cartStore).items.length === 0) {
        _push(`<div class="empty-cart" data-v-0bb6f940><p data-v-0bb6f940>Ваша корзина пуста</p>`);
        _push(ssrRenderComponent(_component_router_link, {
          to: "/catalog",
          class: "continue-shopping"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Перейти к каталог `);
            } else {
              return [
                createTextVNode(" Перейти к каталог ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<div class="cart-content" data-v-0bb6f940><div class="cart-items" data-v-0bb6f940><!--[-->`);
        ssrRenderList(unref(cartStore).items, (item) => {
          _push(`<div class="cart-item" data-v-0bb6f940><img${ssrRenderAttr("src", getImage(item.image_url))}${ssrRenderAttr("alt", item.name)} class="item-image" data-v-0bb6f940><div class="item-details" data-v-0bb6f940><h3 data-v-0bb6f940>${ssrInterpolate(item.name)}</h3></div><div class="item-actions" data-v-0bb6f940><button class="remove-btn" data-v-0bb6f940>×</button></div></div>`);
        });
        _push(`<!--]--></div><div class="cart-summary" data-v-0bb6f940><h3 data-v-0bb6f940>Итого</h3><div class="summary-row" data-v-0bb6f940><span data-v-0bb6f940>Товары (${ssrInterpolate(unref(cartStore).totalItems)})</span></div><div class="summary-actions" data-v-0bb6f940>`);
        _push(ssrRenderComponent(ButtonComp, { onClick: scrollToConsultation }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Оформить заказ`);
            } else {
              return [
                createTextVNode("Оформить заказ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(ButtonComp, { variant: "transparent" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_router_link, {
                to: "/catalog",
                class: "continue-shopping"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Перейти к каталог `);
                  } else {
                    return [
                      createTextVNode(" Перейти к каталог ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_router_link, {
                  to: "/catalog",
                  class: "continue-shopping"
                }, {
                  default: withCtx(() => [
                    createTextVNode(" Перейти к каталог ")
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div></div>`);
      }
      _push(`</div>`);
      _push(ssrRenderComponent(ConsultationRequest, {
        ref_key: "consultationRef",
        ref: consultationRef,
        "is-from-cart": true
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Оставьте заявку, чтобы обсудить дальнейшие детали`);
          } else {
            return [
              createTextVNode("Оставьте заявку, чтобы обсудить дальнейшие детали")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(FooterComp, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/Basket.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Basket = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-0bb6f940"]]);
const routes = [
  {
    path: "/",
    name: MainPage,
    component: MainPage,
    props: true,
    meta: {
      title: "Victory Oil Energy - Главная",
      description: "Производство высококачественных аналоговых нефтегазовых деталей"
    }
  },
  {
    path: "/about-us",
    name: AboutUsPage,
    component: AboutUsPage,
    props: true,
    meta: {
      title: "О компании | Victory Oil Energy",
      description: "Информация о компании Victory Oil Energy и нашей деятельности"
    }
  },
  {
    path: "/contacts",
    name: ContactsPage,
    component: ContactsPage,
    props: true,
    meta: {
      title: "Контакты | Victory Oil Energy",
      description: "Как связаться с Victory Oil Energy - адреса, телефоны, электронная почта"
    }
  },
  {
    path: "/catalog",
    name: "catalog",
    component: CatalogPage,
    props: (route) => ({ categoryId: route.query.category }),
    meta: {
      title: "Каталог продукции | Victory Oil Energy",
      description: "Каталог нефтегазовых компонентов и деталей производства Victory Oil Energy"
    }
  },
  {
    path: "/product/:id",
    name: "product",
    component: ProductPage,
    props: true
  },
  {
    path: "/admin/login",
    name: "AdminLogin",
    component: () => Promise.resolve().then(() => AdminLogin$1),
    meta: { requiresGuest: true }
  },
  {
    path: "/admin",
    component: () => Promise.resolve().then(() => AdminLayout$1),
    meta: { requiresAuth: true },
    children: [
      {
        path: "",
        redirect: "/admin/dashboard"
      },
      {
        path: "dashboard",
        name: "AdminDashboard",
        component: () => Promise.resolve().then(() => AdminDashboard$1)
      },
      {
        path: "products",
        name: "AdminProducts",
        component: () => Promise.resolve().then(() => AdminProducts$1)
      },
      {
        path: "products/new",
        name: "AdminNewProduct",
        component: () => import("./assets/EditProduct-BrhwHCL6.js"),
        props: { isNew: true }
      },
      {
        path: "products/edit/:id",
        name: "AdminEditProduct",
        component: () => import("./assets/EditProduct-BrhwHCL6.js"),
        props: true
      },
      {
        path: "/admin/categories",
        name: "AdminCategories",
        component: () => import("./assets/AdminCategories-1RsN7aEU.js"),
        meta: { requiresAuth: true, admin: true }
      },
      {
        path: "/admin/categories/new",
        name: "CreateCategory",
        component: () => import("./assets/EditCategory-BZpqlACw.js"),
        meta: { requiresAuth: true, admin: true }
      },
      {
        path: "/admin/categories/edit/:id",
        name: "EditCategory",
        component: () => import("./assets/EditCategory-BZpqlACw.js"),
        meta: { requiresAuth: true, admin: true },
        props: true
      },
      {
        path: "/admin/consultations",
        name: "AdminConsultation",
        component: () => import("./assets/AdminConsultation-DDWbbCpX.js")
      }
    ]
  },
  {
    path: "/privacy-policy",
    name: "PrivacyPolicy",
    component: PrivacyPolicy
  },
  {
    path: "/basket",
    name: "Basket",
    component: Basket
  }
];
function createAppRouter() {
  const router = createRouter({
    history: createMemoryHistory(),
    routes
  });
  router.beforeEach(async (to, from, next) => {
    const isAuthenticated = await validateToken();
    if (to.meta.requiresAuth && !isAuthenticated) {
      return next("/admin/login");
    }
    if (to.meta.requiresGuest && isAuthenticated) {
      return next("/admin");
    }
    next();
  });
  router.afterEach((to, from) => {
    if (typeof window !== "undefined") {
      if (to.hash) {
        setTimeout(() => {
          const element = document.querySelector(to.hash);
          if (element) element.scrollIntoView({ behavior: "smooth" });
        }, 500);
      } else {
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
    }
  });
  router.afterEach((to) => {
    var _a, _b;
    if (typeof document !== "undefined") {
      document.title = ((_a = to.meta) == null ? void 0 : _a.title) || "Victory Oil Energy";
      let metaDescription = document.querySelector('meta[name="description"]');
      if (!metaDescription) {
        metaDescription = document.createElement("meta");
        metaDescription.name = "description";
        document.head.appendChild(metaDescription);
      }
      metaDescription.content = ((_b = to.meta) == null ? void 0 : _b.description) || "Производство аналоговых нефтегазовых деталей";
    }
  });
  return router;
}
async function createApp(url, initialData = {}) {
  const app = createSSRApp(App);
  const router = createAppRouter();
  const pinia = createPinia();
  setActivePinia(pinia);
  app.provide("initialProducts", initialData.products || []);
  app.provide("initialCategories", initialData.categories || []);
  app.use(router);
  app.use(pinia);
  if (url) {
    try {
      await router.push(url);
      await router.isReady();
    } catch (err) {
      console.error("Router error:", err);
    }
  }
  return { app, router, pinia };
}
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
let criticalCSS = "";
try {
  const cssPath = resolve(__dirname, "./src/style.css");
  criticalCSS = fs.readFileSync(cssPath, "utf-8");
} catch (e) {
  console.warn("Critical CSS not found:", e.message);
}
async function render(url, manifest) {
  var _a, _b;
  try {
    const [products, categories] = await Promise.all([
      fetchProducts(),
      fetchCategories()
    ]);
    const preloadImage = products[0] ? `http://localhost:3000${products[0].image_url}` : null;
    const { app, router, pinia } = await createApp(url, { products, categories });
    const ctx = {};
    const appHtml = await renderToString(app, ctx);
    const currentRoute = router.currentRoute.value;
    const meta = {
      title: ((_a = currentRoute.meta) == null ? void 0 : _a.title) || "Victory Oil Energy",
      description: ((_b = currentRoute.meta) == null ? void 0 : _b.description) || "Производство аналоговых нефтегазовых деталей"
    };
    const cssLinks = [];
    if (manifest && ctx.modules) {
      for (const id of ctx.modules) {
        const files = manifest[id];
        if (files == null ? void 0 : files.css) {
          cssLinks.push(...files.css.map((file) => `<link rel="stylesheet" href="${file}">`));
        }
      }
    }
    return `
<!DOCTYPE html>
<html lang="ru">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>${meta.title}</title>
    <meta name="description" content="${meta.description}">
    <link rel="icon" href="/favicon.ico">
    ${criticalCSS ? `<style>${criticalCSS}</style>` : ""}
    ${cssLinks.join("\n")}
    ${preloadImage ? `<link rel="preload" as="image" href="${preloadImage}" fetchpriority="high">` : ""}
  </head>
  <body>
    <div id="app">${appHtml}</div>
    <script type="module" src="/entry-client.js"><\/script>
  </body>
</html>`;
  } catch (err) {
    console.error("Render error:", err);
    return `<!DOCTYPE html><html><head><title>Error</title></head><body>Server error occurred</body></html>`;
  }
}
export {
  _export_sfc as _,
  fetchProductById as a,
  fetchCategoryById as b,
  fetchCategories as f,
  render
};
