import { ref, onMounted, computed, resolveComponent, mergeProps, unref, withCtx, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrRenderComponent } from "vue/server-renderer";
import { useRoute, useRouter } from "vue-router";
import { _ as _export_sfc, f as fetchCategories, a as fetchProductById } from "../entry-server.js";
import "@vue/server-renderer";
import "axios";
import "pinia";
import "fs";
import "url";
import "path";
const _sfc_main = {
  __name: "EditProduct",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    useRouter();
    const productId = route.params.id;
    const loading = ref(false);
    const error = ref("");
    const imagePreview = ref("");
    const currentImage = ref("");
    const categories = ref([]);
    const form = ref({
      name: "",
      description: "",
      category_id: "",
      image: null
    });
    const getImageUrl = (imagePath) => {
      if (!imagePath) return "";
      if (imagePath.startsWith("http")) return imagePath;
      return `http://localhost:3000${imagePath.startsWith("/") ? "" : "/"}${imagePath}`;
    };
    onMounted(async () => {
      try {
        categories.value = await fetchCategories();
        if (productId) {
          const product = await fetchProductById(productId);
          form.value = {
            name: product.name,
            description: product.description,
            category_id: product.category_id,
            image: null
          };
          if (product.image_url) {
            currentImage.value = getImageUrl(product.image_url);
          }
        }
      } catch (err) {
        error.value = "Не удалось загрузить данные товара";
        console.error(err);
      }
    });
    const subcategories = computed(() => {
      return categories.value.filter((category) => category.parent_id !== null);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "edit-product" }, _attrs))} data-v-26611c9a><h2 data-v-26611c9a>${ssrInterpolate(unref(productId) ? "Редактирование товара" : "Добавление товара")}</h2><form class="product-form" enctype="multipart/form-data" data-v-26611c9a><div class="form-group" data-v-26611c9a><label for="name" data-v-26611c9a>Название</label><input type="text" id="name"${ssrRenderAttr("value", form.value.name)} required data-v-26611c9a></div><div class="form-group" data-v-26611c9a><label for="description" data-v-26611c9a>Описание</label><textarea id="description" rows="4" data-v-26611c9a>${ssrInterpolate(form.value.description)}</textarea></div><div class="form-row" data-v-26611c9a><div class="form-group" data-v-26611c9a><label for="category" data-v-26611c9a>Категория</label><select id="category" required data-v-26611c9a><option value="" data-v-26611c9a${ssrIncludeBooleanAttr(Array.isArray(form.value.category_id) ? ssrLooseContain(form.value.category_id, "") : ssrLooseEqual(form.value.category_id, "")) ? " selected" : ""}>Выберите категорию</option><!--[-->`);
      ssrRenderList(subcategories.value, (category) => {
        _push(`<option${ssrRenderAttr("value", category.id)} data-v-26611c9a${ssrIncludeBooleanAttr(Array.isArray(form.value.category_id) ? ssrLooseContain(form.value.category_id, category.id) : ssrLooseEqual(form.value.category_id, category.id)) ? " selected" : ""}>${ssrInterpolate(category.name)}</option>`);
      });
      _push(`<!--]--></select></div></div><div class="form-group" data-v-26611c9a><label for="image" data-v-26611c9a>Фото</label><input type="file" id="image" accept="image/*" data-v-26611c9a>`);
      if (currentImage.value || imagePreview.value) {
        _push(`<div class="image-preview" data-v-26611c9a><img${ssrRenderAttr("src", currentImage.value || imagePreview.value)} alt="Preview" data-v-26611c9a>`);
        if (currentImage.value) {
          _push(`<button type="button" class="remove-btn" data-v-26611c9a> Удалить текущее изображение </button>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="form-actions" data-v-26611c9a><button type="submit"${ssrIncludeBooleanAttr(loading.value) ? " disabled" : ""} data-v-26611c9a>${ssrInterpolate(loading.value ? "Сохранение..." : "Сохранить")}</button>`);
      _push(ssrRenderComponent(_component_router_link, {
        to: "/admin/products",
        class: "cancel-btn"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Отмена `);
          } else {
            return [
              createTextVNode(" Отмена ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      if (error.value) {
        _push(`<p class="error-message" data-v-26611c9a>${ssrInterpolate(error.value)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</form></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/AdminPanel/EditProduct.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const EditProduct = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-26611c9a"]]);
export {
  EditProduct as default
};
