import { ref, computed, onMounted, resolveComponent, mergeProps, unref, withCtx, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrRenderComponent } from "vue/server-renderer";
import { useRoute, useRouter } from "vue-router";
import { _ as _export_sfc, f as fetchCategories, b as fetchCategoryById } from "../entry-server.js";
import "@vue/server-renderer";
import "axios";
import "pinia";
import "fs";
import "url";
import "path";
const _sfc_main = {
  __name: "EditCategory",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    useRouter();
    const categoryId = route.params.id;
    const loading = ref(false);
    const error = ref("");
    const imagePreview = ref("");
    const currentImage = ref("");
    const categories = ref([]);
    const form = ref({
      name: "",
      description: "",
      parent_id: null,
      image: null
    });
    const availableParentCategories = computed(() => {
      const topLevelCategories = categories.value.filter((category) => category.parent_id === null);
      return topLevelCategories.filter((cat) => !categoryId || cat.id !== parseInt(categoryId));
    });
    const getImageUrl = (imagePath) => {
      if (!imagePath) return "";
      if (imagePath.startsWith("http")) return imagePath;
      return `http://localhost:3000${imagePath.startsWith("/") ? "" : "/"}${imagePath}`;
    };
    onMounted(async () => {
      try {
        categories.value = await fetchCategories();
        if (categoryId) {
          const category = await fetchCategoryById(categoryId);
          form.value = {
            name: category.name,
            description: category.description,
            parent_id: category.parent_id,
            image: null
          };
          if (category.image_url) {
            currentImage.value = getImageUrl(category.image_url);
          }
        }
      } catch (err) {
        error.value = "Не удалось загрузить данные категории";
        console.error(err);
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "edit-category" }, _attrs))} data-v-1a5a3612><h2 data-v-1a5a3612>${ssrInterpolate(unref(categoryId) ? "Редактирование категории" : "Создание категории")}</h2><form class="category-form" enctype="multipart/form-data" data-v-1a5a3612><div class="form-group" data-v-1a5a3612><label for="name" data-v-1a5a3612>Название</label><input type="text" id="name"${ssrRenderAttr("value", form.value.name)} required data-v-1a5a3612></div><div class="form-group" data-v-1a5a3612><label for="description" data-v-1a5a3612>Описание</label><textarea id="description" rows="4" required data-v-1a5a3612>${ssrInterpolate(form.value.description)}</textarea></div><div class="form-group" data-v-1a5a3612><label for="parent" data-v-1a5a3612>Родительская категория</label><select id="parent" data-v-1a5a3612><option${ssrRenderAttr("value", null)} data-v-1a5a3612${ssrIncludeBooleanAttr(Array.isArray(form.value.parent_id) ? ssrLooseContain(form.value.parent_id, null) : ssrLooseEqual(form.value.parent_id, null)) ? " selected" : ""}>Без родительской категории</option><!--[-->`);
      ssrRenderList(availableParentCategories.value, (category) => {
        _push(`<option${ssrRenderAttr("value", category.id)} data-v-1a5a3612${ssrIncludeBooleanAttr(Array.isArray(form.value.parent_id) ? ssrLooseContain(form.value.parent_id, category.id) : ssrLooseEqual(form.value.parent_id, category.id)) ? " selected" : ""}>${ssrInterpolate(category.name)}</option>`);
      });
      _push(`<!--]--></select></div><div class="form-group" data-v-1a5a3612><label for="image" data-v-1a5a3612>Изображение</label><input type="file" id="image" accept="image/*" data-v-1a5a3612>`);
      if (currentImage.value || imagePreview.value) {
        _push(`<div class="image-preview" data-v-1a5a3612><img${ssrRenderAttr("src", currentImage.value || imagePreview.value)} alt="Preview" data-v-1a5a3612>`);
        if (currentImage.value) {
          _push(`<button type="button" class="remove-btn" data-v-1a5a3612> Удалить текущее изображение </button>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="form-actions" data-v-1a5a3612><button type="submit"${ssrIncludeBooleanAttr(loading.value) ? " disabled" : ""} data-v-1a5a3612>${ssrInterpolate(loading.value ? "Сохранение..." : "Сохранить")}</button>`);
      _push(ssrRenderComponent(_component_router_link, {
        to: "/admin/categories",
        class: "cancel-btn"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Отмена `);
          } else {
            return [
              createTextVNode(" Отмена ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      if (error.value) {
        _push(`<p class="error-message" data-v-1a5a3612>${ssrInterpolate(error.value)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</form></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/AdminPanel/EditCategory.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const EditCategory = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-1a5a3612"]]);
export {
  EditCategory as default
};
