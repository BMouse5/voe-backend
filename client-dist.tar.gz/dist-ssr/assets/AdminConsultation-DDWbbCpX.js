import { ref, onMounted, mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderList, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual } from "vue/server-renderer";
import axios from "axios";
import { _ as _export_sfc } from "../entry-server.js";
import "@vue/server-renderer";
import "vue-router";
import "pinia";
import "fs";
import "url";
import "path";
const _sfc_main = {
  __name: "AdminConsultation",
  __ssrInlineRender: true,
  setup(__props) {
    const consultations = ref({ data: [] });
    const loading = ref(true);
    const deleteLoading = ref({});
    const errorMessage = ref("");
    const showDeleteModal = ref(false);
    const deleteMessage = ref("");
    ref(null);
    const fetchConsultations = async () => {
      try {
        loading.value = true;
        const response = await axios.get("http://localhost:3000/api/consultations");
        consultations.value = response.data;
      } catch (error) {
        console.error("Ошибка загрузки заявок:", error);
        errorMessage.value = "Не удалось загрузить список заявок";
      } finally {
        loading.value = false;
      }
    };
    const formatDate = (dateString) => {
      const date = new Date(dateString);
      return date.toLocaleString("ru-RU");
    };
    onMounted(() => {
      fetchConsultations();
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "admin-consultations" }, _attrs))} data-v-d1c5bea4><div class="header" data-v-d1c5bea4><h2 data-v-d1c5bea4>Управление заявками</h2></div>`);
      if (loading.value) {
        _push(`<div class="loading" data-v-d1c5bea4>Загрузка...</div>`);
      } else if (errorMessage.value) {
        _push(`<div class="error-message" data-v-d1c5bea4>${ssrInterpolate(errorMessage.value)}</div>`);
      } else {
        _push(`<table class="consultations-table" data-v-d1c5bea4><thead data-v-d1c5bea4><tr data-v-d1c5bea4><th data-v-d1c5bea4>Имя</th><th data-v-d1c5bea4>Email</th><th data-v-d1c5bea4>Телефон</th><th data-v-d1c5bea4>Сообщение</th><th data-v-d1c5bea4>Статус</th><th data-v-d1c5bea4>Дата создания</th><th data-v-d1c5bea4>Действия</th></tr></thead><tbody data-v-d1c5bea4><!--[-->`);
        ssrRenderList(consultations.value.data, (consultation) => {
          _push(`<tr data-v-d1c5bea4><td data-v-d1c5bea4>${ssrInterpolate(consultation.name)}</td><td data-v-d1c5bea4>${ssrInterpolate(consultation.email)}</td><td data-v-d1c5bea4>${ssrInterpolate(consultation.phone)}</td><td class="message-cell" data-v-d1c5bea4>${ssrInterpolate(consultation.message)}</td><td data-v-d1c5bea4><select class="status-select" data-v-d1c5bea4><option value="1" data-v-d1c5bea4${ssrIncludeBooleanAttr(Array.isArray(consultation.status_id) ? ssrLooseContain(consultation.status_id, "1") : ssrLooseEqual(consultation.status_id, "1")) ? " selected" : ""}>Новая</option><option value="2" data-v-d1c5bea4${ssrIncludeBooleanAttr(Array.isArray(consultation.status_id) ? ssrLooseContain(consultation.status_id, "2") : ssrLooseEqual(consultation.status_id, "2")) ? " selected" : ""}>В обработке</option><option value="3" data-v-d1c5bea4${ssrIncludeBooleanAttr(Array.isArray(consultation.status_id) ? ssrLooseContain(consultation.status_id, "3") : ssrLooseEqual(consultation.status_id, "3")) ? " selected" : ""}>Обработана</option><option value="4" data-v-d1c5bea4${ssrIncludeBooleanAttr(Array.isArray(consultation.status_id) ? ssrLooseContain(consultation.status_id, "4") : ssrLooseEqual(consultation.status_id, "4")) ? " selected" : ""}>Отменена</option></select></td><td data-v-d1c5bea4>${ssrInterpolate(formatDate(consultation.created_at))}</td><td class="actions" data-v-d1c5bea4><button class="delete-btn"${ssrIncludeBooleanAttr(deleteLoading.value[consultation.id]) ? " disabled" : ""} data-v-d1c5bea4>${ssrInterpolate(deleteLoading.value[consultation.id] ? "Удаление..." : "Удалить")}</button></td></tr>`);
        });
        _push(`<!--]--></tbody></table>`);
      }
      if (showDeleteModal.value) {
        _push(`<div class="modal-overlay" data-v-d1c5bea4><div class="modal-content" data-v-d1c5bea4><h3 data-v-d1c5bea4>Подтверждение удаления</h3><p data-v-d1c5bea4>${ssrInterpolate(deleteMessage.value)}</p><div class="modal-actions" data-v-d1c5bea4><button class="confirm-btn" data-v-d1c5bea4>Удалить</button><button class="cancel-btn" data-v-d1c5bea4>Отмена</button></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/AdminPanel/AdminConsultation.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const AdminConsultation = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-d1c5bea4"]]);
export {
  AdminConsultation as default
};
