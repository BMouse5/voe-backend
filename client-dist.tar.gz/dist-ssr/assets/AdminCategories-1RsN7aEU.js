import { ref, onMounted, resolveComponent, mergeProps, withCtx, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { _ as _export_sfc, f as fetchCategories } from "../entry-server.js";
import "@vue/server-renderer";
import "vue-router";
import "axios";
import "pinia";
import "fs";
import "url";
import "path";
const _sfc_main = {
  __name: "AdminCategories",
  __ssrInlineRender: true,
  setup(__props) {
    const categories = ref([]);
    const loading = ref(true);
    const deleteLoading = ref({});
    const showDeleteModal = ref(false);
    const deleteMessage = ref("");
    ref(null);
    const canDelete = ref(false);
    ref(false);
    const getImageUrl = (imagePath) => {
      if (!imagePath) return "";
      if (imagePath.startsWith("http")) return imagePath;
      return `http://localhost:3000${imagePath.startsWith("/") ? "" : "/"}${imagePath}`;
    };
    const getParentName = (parentId) => {
      if (!parentId) return "-";
      const parent = categories.value.find((c) => c.id === parentId);
      return parent ? parent.name : "Неизвестно";
    };
    const loadCategories = async () => {
      try {
        loading.value = true;
        categories.value = await fetchCategories();
      } catch (err) {
        console.error("Ошибка загрузки категорий:", err);
      } finally {
        loading.value = false;
      }
    };
    onMounted(loadCategories);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "admin-categories" }, _attrs))} data-v-fca23d70><div class="header" data-v-fca23d70><h2 data-v-fca23d70>Управление категориями</h2>`);
      _push(ssrRenderComponent(_component_router_link, {
        to: "/admin/categories/new",
        class: "add-btn"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Создать категорию `);
          } else {
            return [
              createTextVNode(" Создать категорию ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      if (loading.value) {
        _push(`<div class="loading" data-v-fca23d70>Загрузка категорий...</div>`);
      } else {
        _push(`<table class="categories-table" data-v-fca23d70><thead data-v-fca23d70><tr data-v-fca23d70><th data-v-fca23d70>ID</th><th data-v-fca23d70>Изображение</th><th data-v-fca23d70>Название</th><th data-v-fca23d70>Родительская категория</th><th data-v-fca23d70>Действия</th></tr></thead><tbody data-v-fca23d70><!--[-->`);
        ssrRenderList(categories.value, (category) => {
          _push(`<tr data-v-fca23d70><td data-v-fca23d70>${ssrInterpolate(category.id)}</td><td class="image-cell" data-v-fca23d70>`);
          if (category.image_url) {
            _push(`<img${ssrRenderAttr("src", getImageUrl(category.image_url))}${ssrRenderAttr("alt", category.name)} class="category-image" data-v-fca23d70>`);
          } else {
            _push(`<span data-v-fca23d70>Нет изображения</span>`);
          }
          _push(`</td><td data-v-fca23d70>${ssrInterpolate(category.name)}</td><td data-v-fca23d70>${ssrInterpolate(getParentName(category.parent_id))}</td><td class="actions" data-v-fca23d70>`);
          _push(ssrRenderComponent(_component_router_link, {
            to: `/admin/categories/edit/${category.id}`,
            class: "edit-btn"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(` Редактировать `);
              } else {
                return [
                  createTextVNode(" Редактировать ")
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`<button class="delete-btn"${ssrIncludeBooleanAttr(deleteLoading.value[category.id]) ? " disabled" : ""} data-v-fca23d70>${ssrInterpolate(deleteLoading.value[category.id] ? "Удаление..." : "Удалить")}</button></td></tr>`);
        });
        _push(`<!--]--></tbody></table>`);
      }
      if (showDeleteModal.value) {
        _push(`<div class="modal-overlay" data-v-fca23d70><div class="modal-content" data-v-fca23d70><h3 data-v-fca23d70>Подтверждение удаления</h3><p data-v-fca23d70>${ssrInterpolate(deleteMessage.value)}</p><div class="modal-actions" data-v-fca23d70>`);
        if (canDelete.value) {
          _push(`<button class="confirm-btn" data-v-fca23d70> Удалить </button>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<button class="cancel-btn" data-v-fca23d70>${ssrInterpolate(canDelete.value ? "Отмена" : "Закрыть")}</button></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/AdminPanel/AdminCategories.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const AdminCategories = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-fca23d70"]]);
export {
  AdminCategories as default
};
